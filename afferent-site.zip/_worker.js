// afferent.page: the only code that runs on the server.
// POST /api/notify keeps one email address in cloudflare d1 (binding DB, table waitlist) so the
// release note can be sent once; the addresses are deleted after that one email.
// _routes.json sends only /api/* here; every page and file is served as a static asset.

const OK = "you're on it. one email, then we forget you.";
const valid = (email) => email.length <= 254 && /^[^\s@<>()",;:]{1,64}@[^\s@<>()",;:]{1,253}\.[a-z]{2,24}$/i.test(email);

function reply(request, status, message) {
  const wantsJson = (request.headers.get('accept') || '').includes('application/json');
  if (wantsJson) {
    return new Response(JSON.stringify({ ok: status === 200, message }), {
      status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
    });
  }
  const page = `<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>afferent</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#000;color:#ededed;font:16px/1.6 ui-monospace,Menlo,Consolas,monospace;text-align:center;padding:24px}a{color:#ededed}</style>
<p>${message}<br><br><a href="/">back to dendrite</a></p></html>`;
  return new Response(page, { status, headers: { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' } });
}

async function notify(request, env) {
  if (request.method !== 'POST') return new Response('post only', { status: 405, headers: { allow: 'POST' } });
  let email = '', trap = '';
  try {
    if ((request.headers.get('content-type') || '').includes('application/json')) {
      const body = await request.json();
      email = body.email; trap = body.website;
    } else {
      const body = await request.formData();
      email = body.get('email'); trap = body.get('website');
    }
  } catch { /* an unreadable body is treated as empty */ }
  if (trap) return reply(request, 200, OK);                       // a bot filled the hidden field
  email = String(email || '').trim().toLowerCase();
  if (!valid(email)) return reply(request, 400, "that doesn't look like an email address.");
  if (!env.DB) return reply(request, 503, 'this is not working yet. write to hello@afferent.page.');
  await env.DB.prepare('INSERT OR IGNORE INTO waitlist (email, created_at) VALUES (?1, ?2)')
    .bind(email, new Date().toISOString()).run();
  return reply(request, 200, OK);
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/api/notify') {
      try { return await notify(request, env); }
      catch { return reply(request, 500, 'that did not work. write to hello@afferent.page instead.'); }
    }
    return env.ASSETS.fetch(request);
  },
};
