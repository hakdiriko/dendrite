// afferent. the small life of the pages, kept apart from the sound (site.js).
//
//   1. chrome       rulers, the cell under the pointer, a formula bar for what it points at, page count
//   2. scroll       reveals of four kinds, numbers that count, the paper sheet, values tied to scroll
//   3. hovers       one per kind of thing, each one acting out what the thing does
//   4. home         the hidden layer under the blank page, the works sheet, the type specimen
//   5. transitions  leaving and arriving differ by where you are going
//
// site.js calls AFFERENT_ALIVE.arrive() after every page change, and leave() / enter() around one.
// Without this script every page still reads completely; with reduced motion it stays quiet.

(() => {
  const root = document.documentElement;
  const LANG = root.lang === 'tr' ? 'tr' : 'en';
  const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const fine = matchMedia('(hover: hover) and (pointer: fine)').matches;
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
  const main = () => document.getElementById('content');

  const WORDS = {
    'the joined ff of the wordmark': 'amblemdeki bitişik ff',
    'pilcrow': 'paragraf işareti', 'section': 'bölüm işareti', 'middle dot': 'orta nokta', 'arrow': 'ok',
    'degree': 'derece', 'plus or minus': 'artı eksi', 'times': 'çarpı', 'full stop': 'nokta', 'comma': 'virgül',
    'colon': 'iki nokta', 'semicolon': 'noktalı virgül', 'parenthesis': 'parantez', 'slash': 'eğik çizgi',
    'urbanist light': 'urbanist light', 'fragment mono': 'fragment mono',
    'cap height': 'büyük harf yüksekliği', 'x-height': 'x yüksekliği', 'baseline': 'taban çizgisi', 'descender': 'iniş',
  };
  const w = (s) => (LANG === 'tr' && WORDS[s]) || s;

  // ---------------------------------------------------------------- 1. chrome

  const pointer = { x: -1, y: -1, moved: 0, inside: false };
  let dirty = true;
  addEventListener('pointermove', (e) => {
    if (e.pointerType !== 'mouse' && e.pointerType !== 'pen' && e.type !== 'touchmove') { /* touch still counts for the lens */ }
    pointer.x = e.clientX; pointer.y = e.clientY; pointer.moved = performance.now(); pointer.inside = true; dirty = true;
  }, { passive: true });
  addEventListener('touchmove', (e) => {
    const t = e.touches[0]; if (!t) return;
    pointer.x = t.clientX; pointer.y = t.clientY; pointer.moved = performance.now(); pointer.inside = true; dirty = true;
  }, { passive: true });
  document.addEventListener('pointerleave', () => { pointer.inside = false; dirty = true; });
  addEventListener('scroll', () => { dirty = true; }, { passive: true });
  addEventListener('resize', () => { dirty = true; measureGlyph(); });

  const COLS = 'abcdefghijkl';
  const cellName = (x, y) => COLS[clamp(Math.floor((x / innerWidth) * 12), 0, 11)] + (Math.floor((scrollY + y) / 32) + 1);

  function formulaFor(target) {
    if (!target || !target.closest) return null;
    const glyph = target.closest('.g');
    if (glyph) return `=char("u+${[...glyph.textContent].map((c) => c.codePointAt(0).toString(16).padStart(4, '0')).join(' u+')}")`;
    const cell = target.closest('.cell');
    if (cell) return `=field(feed ${cell.dataset.feed}, space ${cell.dataset.space})`;
    const control = target.closest('[data-action]');
    if (control) {
      const a = control.dataset.action;
      if (a === 'sound') return `=sound(${control.getAttribute('aria-pressed') === 'true' ? 'off' : 'on'})`;
      if (a === 'dry' || a === 'dendrite') return `=chain("${a}")`;
      if (a === 'slower') return '=tempo(-1)';
      if (a === 'faster') return '=tempo(+1)';
      return `=${a}()`;
    }
    const link = target.closest('a[href]');
    if (link) {
      const href = link.getAttribute('href');
      if (href.startsWith('mailto:')) return `=write("${href.slice(7).split('?')[0]}")`;
      if (link.hasAttribute('hreflang')) return `=translate("${link.getAttribute('hreflang')}")`;
      if (href.startsWith('#')) return `=scroll("${href}")`;
      return `=goto("${href}")`;
    }
    if (target.closest('.grid-row.empty')) return '=reserved()';
    if (target.closest('.leaf.first')) return '=blank()';
    const section = target.closest('[data-chapter]');
    if (section) return `=read("${section.dataset.chapter}")`;
    return '';
  }
  let shownFormula = null;
  document.addEventListener('pointerover', (e) => {
    const f = formulaFor(e.target);
    if (f === shownFormula) return;
    shownFormula = f;
    const out = $('[data-formula]');
    if (out) out.textContent = f || '';
  });

  // the lens over the hidden layer: where the pointer is, or wandering on its own when left alone
  const lens = { x: 0.5, y: 0.5 };
  function lensTarget(leaf, rect, now) {
    const recent = now - pointer.moved < 2600;
    if (recent && pointer.inside && pointer.y >= rect.top && pointer.y <= rect.bottom) {
      return { x: (pointer.x - rect.left) / rect.width, y: (pointer.y - rect.top) / rect.height, live: true };
    }
    const s = now / 1000;
    return { x: 0.5 + 0.36 * Math.sin(s * 0.23) * Math.cos(s * 0.07), y: 0.5 + 0.3 * Math.sin(s * 0.17 + 1.3), live: false };
  }

  let pages = [];
  function frame(now) {
    requestAnimationFrame(frame);
    if (document.hidden) return;

    const leaf = $('.leaf.first');
    if (leaf && !reduced) {
      const rect = leaf.getBoundingClientRect();
      if (rect.bottom > 0) {
        const target = lensTarget(leaf, rect, now);
        const k = target.live ? 0.35 : 0.04;
        lens.x += (target.x - lens.x) * k; lens.y += (target.y - lens.y) * k;
        leaf.style.setProperty('--mx', `${(lens.x * 100).toFixed(2)}%`);
        leaf.style.setProperty('--my', `${(lens.y * 100).toFixed(2)}%`);
        leaf.style.setProperty('--lens', target.live ? '1' : '0.7');
      }
    }
    if (!dirty) return;
    dirty = false;

    // rulers and cell
    const x = pointer.x, y = pointer.y;
    const rx = $('.ruler.x'), ry = $('.ruler.y');
    if (rx && x >= 0) {
      rx.style.setProperty('--at', `${x}px`);
      ry.style.setProperty('--at', `${y}px`);
      $('.read', rx).textContent = Math.round(x);
      $('.read', ry).textContent = Math.round(scrollY + y);
      const cell = $('[data-cell]');
      if (cell) cell.textContent = cellName(x, y);
    }
    const max = Math.max(1, document.documentElement.scrollHeight - innerHeight);
    root.style.setProperty('--read', (scrollY / max).toFixed(4));

    // the page count: leaves on the home page, screens elsewhere
    let now1, total;
    if (pages.length) {
      total = pages.length; now1 = 1;
      pages.forEach((p, i) => { if (p.getBoundingClientRect().top < innerHeight * 0.5) now1 = i + 1; });
    } else {
      total = Math.max(1, Math.ceil(document.documentElement.scrollHeight / innerHeight - 0.15));
      now1 = clamp(Math.floor((scrollY + innerHeight * 0.5) / innerHeight) + 1, 1, total);
    }
    const no = $('[data-pageno]'), of = $('[data-pages]');
    if (no && no.textContent !== String(now1)) {
      no.textContent = now1;
      if (!reduced) no.animate([{ transform: 'translateY(-60%)', opacity: 0 }, { transform: 'none', opacity: 1 }], { duration: 260, easing: 'ease-out' });
    }
    if (of) of.textContent = total;

    // values tied to scroll: the first leaf folds toward its centre, the dendrite name gathers echoes
    for (const el of $$('[data-scroll]')) {
      const r = el.getBoundingClientRect();
      el.style.setProperty('--p', clamp(-r.top / Math.max(1, r.height), 0, 1).toFixed(3));
    }
  }
  requestAnimationFrame(frame);

  // ---------------------------------------------------------------- 2. scroll

  const shown = new IntersectionObserver((entries) => {
    for (const entry of entries) {
      if (!entry.isIntersecting) continue;
      const el = entry.target;
      el.classList.add('in');
      for (const typed of el.querySelectorAll(':scope > [data-reveal="type"]')) typed.classList.add('in');
      shown.unobserve(el);
      for (const n of $$('[data-count]', el).concat(el.matches('[data-count]') ? [el] : [])) count(n);
    }
  }, { threshold: 0.2, rootMargin: '0px 0px -6% 0px' });

  function count(el) {
    const to = Number(el.dataset.count);
    if (reduced || !Number.isFinite(to)) return;
    const start = performance.now(), length = 700;
    const step = (now) => {
      const t = clamp((now - start) / length, 0, 1);
      el.textContent = Math.round(to * (1 - (1 - t) ** 3));
      if (t < 1) requestAnimationFrame(step);
    };
    el.textContent = '0';
    requestAnimationFrame(step);
  }

  // a sheet of paper: while a [data-paper] section holds the middle of the screen, the site turns to paper
  const paper = new IntersectionObserver((entries) => {
    for (const entry of entries) if (entry.target.isConnected) document.body.classList.toggle('paper', entry.isIntersecting);
  }, { rootMargin: '-48% 0px -48% 0px' });

  // ---------------------------------------------------------------- 3. hovers
  //
  //   pulse    the wordmark: a ring closes on the centre (afferent: carried toward the centre)
  //   branch   a link to dendrite: branches grow, behind the page or inside the row
  //   face     colophon, the page about the type: its letters change face one by one
  //   section  legal: a § comes in and the words become small print (css)
  //   flap     the language switch: the letters flip through both alphabets and land
  //   type     an address to write to: the words are typed again, with a caret
  //   spike    a "more" link: a spike train runs out along the arrow (css)
  //   ring     sound: rings go out from the dot (css)
  //   axon     footer and text links: a line is drawn under them, left to right (css)
  //   echo     dendrite on a switch: the word repeats to the side; dry stays alone (css)
  //   tempo    slower and faster tick at the speed they lead to (css)

  function auto(scope) {
    for (const a of $$('a[href^="mailto:"]', scope)) a.dataset.hover ||= 'type';
    for (const a of $$('a.more', scope)) a.dataset.hover ||= 'spike';
    for (const a of $$('.text a:not([data-hover]), .part a:not([data-hover]):not(.cta)', scope)) a.dataset.hover = 'axon';
  }

  const timers = new WeakMap();
  const later = (el, fn, ms) => { const list = timers.get(el) || []; list.push(setTimeout(fn, ms)); timers.set(el, list); };
  const stop = (el) => { for (const id of timers.get(el) || []) clearTimeout(id); timers.set(el, []); };

  function letters(el) {
    if (!el.dataset.text) {
      el.dataset.text = el.textContent;
      el.setAttribute('aria-label', el.getAttribute('aria-label') || el.textContent.trim());
      el.innerHTML = [...el.textContent].map((c) => `<span class="ch" aria-hidden="true">${c === ' ' ? '&nbsp;' : c}</span>`).join('');
    }
    return $$('.ch', el);
  }

  const FLAP = 'abcçdefgğhıijklmnoöprsştuüvyz';
  const enterHover = {
    pulse(el) { el.classList.remove('pulsing'); void el.offsetWidth; el.classList.add('pulsing'); },
    branch(el) {
      const canvas = $('canvas.sprout', el);
      if (canvas) return sprout(el, canvas);
      const r = el.getBoundingClientRect();
      const last = Number(el.dataset.grown || 0);
      if (performance.now() - last < 900) return;
      el.dataset.grown = performance.now();
      window.AFFERENT_GROW?.(r.left + r.width / 2, r.bottom + 4, 0.55);
    },
    face(el) {
      const chars = letters(el);
      el.style.minWidth = `${el.getBoundingClientRect().width}px`;
      stop(el);
      chars.forEach((c, i) => later(el, () => c.classList.add('alt'), i * 45));
    },
    flap(el) {
      if (!el.dataset.text) el.dataset.text = el.textContent;
      const word = el.dataset.text;
      stop(el);
      el.style.minWidth = `${el.getBoundingClientRect().width}px`;
      for (let f = 0; f <= 9 + word.length * 2; f++) {
        later(el, () => {
          el.textContent = [...word].map((c, i) => (c === ' ' || f >= 4 + i * 2 ? c : FLAP[Math.floor(Math.random() * FLAP.length)])).join('');
        }, f * 42);
      }
    },
    type(el) {
      const node = el.querySelector('[data-label]') || el;
      if (!el.dataset.text) el.dataset.text = node.textContent;
      const word = el.dataset.text;
      stop(el);
      el.style.minWidth = `${el.getBoundingClientRect().width}px`;
      el.classList.add('typing');
      node.textContent = '';
      [...word].forEach((c, i) => later(el, () => { node.textContent = word.slice(0, i + 1); }, 60 + i * 26));
      later(el, () => el.classList.remove('typing'), 60 + word.length * 26 + 900);
    },
  };
  const leaveHover = {
    face(el) {
      stop(el);
      const chars = $$('.ch', el);
      chars.forEach((c, i) => later(el, () => c.classList.remove('alt'), i * 30));
      later(el, () => { el.style.minWidth = ''; }, chars.length * 30 + 40);
    },
    flap(el) { stop(el); el.textContent = el.dataset.text; el.style.minWidth = ''; },
    type(el) {
      stop(el);
      const node = el.querySelector('[data-label]') || el;
      node.textContent = el.dataset.text; el.classList.remove('typing'); el.style.minWidth = '';
    },
    branch(el) { const canvas = $('canvas.sprout', el); if (canvas) wither(canvas); },
  };

  let hovered = null;
  function hoverTo(el) {
    if (el === hovered) return;
    if (hovered) leaveHover[hovered.dataset.hover]?.(hovered);
    hovered = el;
    if (el && !reduced) enterHover[el.dataset.hover]?.(el);
  }
  document.addEventListener('pointerover', (e) => hoverTo(e.target.closest?.('[data-hover]') || null));
  document.addEventListener('focusin', (e) => hoverTo(e.target.closest?.('[data-hover]') || null));
  document.addEventListener('animationend', (e) => { if (e.animationName === 'inward') e.target.classList.remove('pulsing'); });

  // the works sheet: the column of the cell under the pointer lights its header, as in a spreadsheet
  document.addEventListener('pointerover', (e) => {
    const grid = e.target.closest?.('.grid');
    for (const h of $$('.grid .hot')) h.classList.remove('hot');
    if (!grid) return;
    const cell = e.target.closest('[role="cell"]');
    if (!cell) return;
    const index = [...cell.parentElement.children].filter((c) => c.getAttribute('role') === 'cell').indexOf(cell);
    const head = $$('.grid-row.head [role="columnheader"]', grid)[index];
    if (head) head.classList.add('hot');
  });

  // a dendrite, grown into a row of the sheet from its left edge
  function sprout(row, canvas) {
    const r = row.getBoundingClientRect(), dpr = Math.min(2, devicePixelRatio || 1);
    canvas.width = r.width * dpr; canvas.height = r.height * dpr;
    const g = canvas.getContext('2d');
    g.setTransform(dpr, 0, 0, dpr, 0, 0);
    const red = getComputedStyle(root).getPropertyValue('--red').trim() || '#cf3a2e';
    let seed = (Math.random() * 1e9) | 0;
    const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296);
    const segs = [];
    const grow = (x, y, angle, length, depth, t0) => {
      if (depth > 6 || x > r.width * 0.96) return;
      const x2 = x + Math.cos(angle) * length, y2 = clamp(y + Math.sin(angle) * length, 3, r.height - 3);
      segs.push({ x, y, x2, y2, t0, t1: t0 + 0.14, w: Math.max(0.5, 1.6 - depth * 0.22), depth });
      const n = depth < 2 ? 2 : rnd() < 0.6 ? 2 : 1;
      for (let i = 0; i < n; i++) grow(x2, y2, angle + (rnd() - 0.5) * 1.3, length * (0.72 + rnd() * 0.25), depth + 1, t0 + 0.12);
    };
    grow(0, r.height / 2, (rnd() - 0.5) * 0.3, Math.min(150, r.width / 7), 0, 0);
    canvas.style.opacity = '1';
    const start = performance.now();
    canvas._run = start;
    const draw = (now) => {
      if (canvas._run !== start) return;
      const t = (now - start) / 1000;
      g.clearRect(0, 0, r.width, r.height);
      g.strokeStyle = red; g.fillStyle = red; g.lineCap = 'round';
      for (const s of segs) {
        const k = clamp((t - s.t0) / (s.t1 - s.t0), 0, 1);
        if (!k) continue;
        g.globalAlpha = 0.55 - s.depth * 0.05;
        g.lineWidth = s.w;
        g.beginPath(); g.moveTo(s.x, s.y); g.lineTo(s.x + (s.x2 - s.x) * k, s.y + (s.y2 - s.y) * k); g.stroke();
        if (k === 1 && s.depth === 6) { g.globalAlpha = 0.8; g.beginPath(); g.arc(s.x2, s.y2, 1.4, 0, 7); g.fill(); }
      }
      if (t < 1.3) requestAnimationFrame(draw);
    };
    requestAnimationFrame(draw);
  }
  function wither(canvas) { canvas._run = 0; canvas.style.opacity = '0'; }

  // ---------------------------------------------------------------- 4. home

  // the type specimen: every glyph can be pointed at; left alone, it reads through the set itself
  const NAMES = { '¶': 'pilcrow', '§': 'section', '·': 'middle dot', '→': 'arrow',
    '°': 'degree', '±': 'plus or minus', '×': 'times', '.': 'full stop', ',': 'comma', ':': 'colon', ';': 'semicolon',
    '(': 'parenthesis', ')': 'parenthesis', '/': 'slash' };
  let specimenTimer = 0, specimenHeld = false;
  function specimen(scope) {
    const box = $('.specimen', scope);
    clearInterval(specimenTimer);
    if (!box) return;
    for (const set of $$('.words-set, .mono-set', box)) {
      if (set.dataset.split) continue;
      set.dataset.split = '1';
      set.innerHTML = set.textContent.trim().split(/\s+/).map((g) => `<span class="g" tabindex="-1">${g}</span>`).join(' ');
    }
    const big = $('[data-glyph]', box), name = $('[data-glyph-name]', box);
    const showGlyph = (g) => {
      const mono = !!g.closest('.mono-set');
      const text = g.textContent;
      if (big.textContent === text && big.classList.contains('mono') === mono) return;
      big.textContent = text;
      big.classList.toggle('mono', mono);
      const face = w(mono ? 'fragment mono' : 'urbanist light');
      const code = [...text].map((c) => 'u+' + c.codePointAt(0).toString(16).padStart(4, '0')).join(' ');
      name.textContent = `${face}. ${code}${NAMES[text] ? '. ' + w(NAMES[text]) : ''}.`;
      for (const x of $$('.g.on', box)) x.classList.remove('on');
      g.classList.add('on');
      if (!reduced) big.animate([{ opacity: 0, transform: 'translateY(6%) scale(0.96)' }, { opacity: 1, transform: 'none' }], { duration: 320, easing: 'cubic-bezier(0.2, 0.7, 0.2, 1)' });
      measureGlyph();
    };
    box.addEventListener('pointerover', (e) => { const g = e.target.closest('.g'); if (g) { specimenHeld = true; showGlyph(g); } });
    box.addEventListener('pointerleave', () => { specimenHeld = false; });
    box.addEventListener('click', (e) => { const g = e.target.closest('.g'); if (g) showGlyph(g); });
    const all = $$('.g', box);
    let i = 0;
    if (!reduced) specimenTimer = setInterval(() => {
      if (specimenHeld || document.hidden || !box.isConnected) return;
      const r = box.getBoundingClientRect();
      if (r.bottom < 0 || r.top > innerHeight) return;
      i = (i + 1) % all.length;
      showGlyph(all[i]);
    }, 1800);
  }

  // the guide lines of the large glyph come from the font itself, measured on a canvas
  const ruler2d = document.createElement('canvas').getContext('2d');
  function measureGlyph() {
    const big = $('[data-glyph]');
    if (!big) return;
    const cs = getComputedStyle(big);
    const size = parseFloat(cs.fontSize);
    ruler2d.font = `${cs.fontWeight} ${size}px ${cs.fontFamily}`;
    const H = ruler2d.measureText('H'), x = ruler2d.measureText('x'), p = ruler2d.measureText('p');
    const ascent = H.fontBoundingBoxAscent, descent = H.fontBoundingBoxDescent;
    if (!ascent) return;
    const lineHeight = parseFloat(cs.lineHeight) || size;
    const base = (lineHeight - (ascent + descent)) / 2 + ascent + big.offsetTop;
    const box = big.parentElement;
    box.style.setProperty('--base', `${base}px`);
    box.style.setProperty('--cap', `${base - H.actualBoundingBoxAscent}px`);
    box.style.setProperty('--xh', `${base - x.actualBoundingBoxAscent}px`);
    box.style.setProperty('--desc', `${base + p.actualBoundingBoxDescent}px`);
  }
  document.fonts?.ready.then(measureGlyph);

  function guides(scope) {
    const box = $('.glyph', scope);
    if (!box || $('.guide', box)) return;
    for (const [k, label] of [['cap', 'cap height'], ['xh', 'x-height'], ['base', 'baseline'], ['desc', 'descender']]) {
      const line = document.createElement('i');
      line.className = `guide ${k}`;
      line.style.top = `var(--${k})`;
      line.innerHTML = `<b class="mono">${w(label)}</b>`;
      box.prepend(line);
    }
  }

  function today(scope) {
    for (const el of $$('[data-today]', scope)) {
      el.textContent = new Date().toLocaleDateString(LANG === 'tr' ? 'tr-TR' : 'en-GB', { day: 'numeric', month: 'long', year: 'numeric' });
    }
  }

  // the dendrite page's sections each come in their own way
  function vary(scope) {
    $$('.scene .reveal', scope).forEach((el, i) => el.classList.add(['r-rise', 'r-focus', 'r-scan', 'r-rise', 'r-wide'][i % 5]));
  }

  // ---------------------------------------------------------------- arrive

  function arrive() {
    const m = main();
    if (!m) return;
    hovered = null;
    document.body.classList.remove('paper');
    paper.disconnect();
    auto(document);
    today(m);
    guides(m);
    specimen(m);
    vary(m);
    // a clipped element never counts as seen, so typed lines are watched through their parent
    for (const el of $$('[data-reveal], .scene .reveal', m)) shown.observe(el.dataset.reveal === 'type' ? el.parentElement : el);
    for (const el of $$('[data-paper]', m)) paper.observe(el);
    pages = $$('[data-page-no]', m);
    if (pages.length) root.dataset.leaves = ''; else delete root.dataset.leaves;
    for (const el of $$('.leaf.first, [data-echo]', m)) el.closest('section').setAttribute('data-scroll', '');
    root.dataset.kind = m.dataset.page || '';
    measureGlyph();
    dirty = true;
  }

  // ---------------------------------------------------------------- 5. transitions
  //
  //   signal   into dendrite: a line fires across from where you clicked and opens into the next page
  //   inward   home to afferent: the page is drawn in toward the centre, and the next arrives from it
  //   feed     to a text page: the sheet feeds up and out, like paper from a printer, under a scan line

  let point = { x: innerWidth / 2, y: innerHeight / 2 };
  addEventListener('pointerdown', (e) => { point = { x: e.clientX, y: e.clientY }; }, true);
  addEventListener('keydown', () => { point = { x: innerWidth / 2, y: innerHeight / 2 }; }, true);

  const veil = () => $('.veil');
  const ease = 'cubic-bezier(0.2, 0.7, 0.2, 1)', easeIn = 'cubic-bezier(0.6, 0, 0.8, 0.4)';
  let outgoing = null;
  const done = (a) => a.finished.catch(() => {});

  function kindOf(from, to) {
    const isDendrite = (p) => /^(\/tr)?\/dendrite\//.test(p);
    if (isDendrite(to) && !isDendrite(from)) return 'signal';
    if (/^(\/tr)?\/$/.test(to)) return 'inward';
    return 'feed';
  }

  async function leave(from, to) {
    const m = main(), v = veil();
    if (reduced || !m || !v) return null;
    const kind = kindOf(from, to);
    const y = clamp(point.y, 0, innerHeight), x = clamp(point.x, 0, innerWidth);
    v.className = `veil ${kind}`;
    v.style.setProperty('--y', `${y}px`);
    v.style.setProperty('--x', `${x}px`);
    m.style.transformOrigin = `50% ${scrollY + innerHeight / 2}px`;
    if (kind === 'signal') {
      v.innerHTML = '<i class="axon"></i>';
      outgoing = m.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 300, easing: 'ease-in', fill: 'forwards' });
      await done($('.axon', v).animate([{ transform: 'scaleX(0)' }, { transform: 'scaleX(1)' }], { duration: 260, easing: easeIn, fill: 'forwards' }));
      await done(v.animate([{ clipPath: `inset(${y}px 0 ${innerHeight - y - 2}px 0)` }, { clipPath: 'inset(0 0 0 0)' }],
        { duration: 220, easing: easeIn, fill: 'forwards' }));
    } else if (kind === 'inward') {
      v.innerHTML = '<i class="ring"></i>';
      $('.ring', v).animate([{ transform: 'translate(-50%, -50%) scale(2.6)', opacity: 0 }, { opacity: 0.9, offset: 0.4 }, { transform: 'translate(-50%, -50%) scale(0)', opacity: 1 }],
        { duration: 420, easing: easeIn, fill: 'forwards' });
      outgoing = m.animate([{ transform: 'none', opacity: 1 }, { transform: 'scale(0.9)', opacity: 0 }], { duration: 380, easing: easeIn, fill: 'forwards' });
      await done(outgoing);
    } else {
      v.innerHTML = '<i class="scan"></i>';
      $('.scan', v).animate([{ transform: 'translateY(0)' }, { transform: `translateY(${innerHeight}px)` }], { duration: 340, easing: 'linear', fill: 'forwards' });
      outgoing = m.animate([{ transform: 'none', opacity: 1, clipPath: 'inset(0 0 0 0)' }, { transform: 'translateY(-7vh)', opacity: 0 }],
        { duration: 320, easing: easeIn, fill: 'forwards' });
      await done(outgoing);
    }
    return kind;
  }

  function enter(kind) {
    const m = main(), v = veil();
    outgoing?.cancel(); outgoing = null;
    if (!kind || !m || !v) { if (v) { v.className = 'veil'; v.innerHTML = ''; v.getAnimations().forEach((a) => a.cancel()); } return; }
    m.style.transformOrigin = `50% ${scrollY + innerHeight / 2}px`;
    const clear = () => { v.getAnimations().forEach((a) => a.cancel()); v.className = 'veil'; v.innerHTML = ''; };
    if (kind === 'signal') {
      const mid = innerHeight / 2;
      v.getAnimations().forEach((a) => a.cancel());
      const open = v.animate([{ clipPath: 'inset(0 0 0 0)' }, { clipPath: `inset(${mid}px 0 ${mid}px 0)` }], { duration: 460, easing: ease, fill: 'forwards' });
      m.animate([{ opacity: 0, transform: 'scaleY(0.96)' }, { opacity: 1, transform: 'none' }], { duration: 520, easing: ease });
      done(open).then(clear);
    } else if (kind === 'inward') {
      clear();
      m.animate([{ opacity: 0, transform: 'scale(1.06)' }, { opacity: 1, transform: 'none' }], { duration: 520, easing: ease });
    } else {
      done(m.animate([{ opacity: 0, transform: 'translateY(7vh)' }, { opacity: 1, transform: 'none' }], { duration: 460, easing: ease })).then(clear);
    }
  }

  window.AFFERENT_ALIVE = { arrive, leave, enter };
})();
