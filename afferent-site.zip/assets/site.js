// afferent. one script for every page.
//
//   1. take      the loop: a list of events, and recordings of them (dry, and through dendrite)
//   2. clock     one position in the loop, shared by the drawing and the sound
//   3. branches  the event layer behind every page: each event grows its repeats
//   4. sound     runs the dendrite engine live in the page, or plays recordings made with it
//   5. controls  every sound control on the site, wherever it appears
//   6. stereo    the live display of the stereo field
//   7. field     the playable feed / space field, and the videos of the plug-in window
//   8. pages     swaps the page content on navigation, so the sound does not stop
//
// Without this script the site is a static, silent set of pages and still reads completely.

// the build stamps ?v=... on this script's address; the files it loads carry the same stamp,
// so a returning browser never mixes a new page with an old engine
const VERSION = (() => { try { return new URL(document.currentScript.src).search; } catch { return ''; } })();
const TAKE = window.AFFERENT_TAKE;                 // from assets/take.js
const STAB = window.AFFERENT_STAB;                 // from assets/stab.js: the source dendrite plays
const EMBED = window.AFFERENT_EMBED ?? null;       // only set in the single-file preview build
const $ = (id) => document.getElementById(id);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const main = document.querySelector('main');

// words this script writes itself. the pages carry their own text; /tr/ pages set lang="tr".
const LANG = document.documentElement.lang === 'tr' ? 'tr' : 'en';
const TR = {
  'sound unavailable': 'ses kullanılamıyor', 'loading': 'yükleniyor', 'sound': 'ses', 'sound off': 'ses kapalı',
  'sound on': 'ses açık',
  'the engine of dendrite is running in this page. drag the light. hold the dark to throw.':
    'dendrite motoru bu sayfada çalışıyor. ışığı sürükle. throw için karanlığa basılı tut.',
  'nine recordings made with the engine of dendrite, one per point. drag the light.':
    'dendrite motoruyla yapılmış dokuz kayıt, her nokta için bir tane. ışığı sürükle.',
  'drag the light.': 'ışığı sürükle.',
  slower: 'yavaş', faster: 'hızlı', tempo: 'tempo',
  'windows installer': 'windows kurulum dosyası',
  '7.2 mb. puts dendrite.vst3 in the system vst3 folder.': '7,2 mb. dendrite.vst3\'ü sistemin vst3 klasörüne koyar.',
  'download for macos': 'macos için indir',
  '23.2 mb. vst3 and au, apple silicon and intel. not code-signed: allow it once.':
    '23,2 mb. vst3 ve au, apple silicon ve intel. kod imzalı değil: bir kez izin ver.',
  'download for linux': 'linux için indir', '7.0 mb. vst3.': '7,0 mb. vst3.',
  'dendrite runs on a computer. open afferent.page there, or pick a file below.':
    'dendrite bir bilgisayarda çalışır. afferent.page\'i orada aç ya da aşağıdan bir dosya seç.',
  'pick the file for your system.': 'sistemine uygun dosyayı seç.',
  afferent: 'afferent', works: 'işler', notes: 'notlar', type: 'yazı', 'in the lab': 'laboratuvarda', 'coming soon': 'yakında', specification: 'özellikler',
  dendrite: 'dendrite', window: 'pencere', repeats: 'tekrarlar', stereo: 'stereo', field: 'alan', fly: 'sinek',
  inside: 'içeride', download: 'indir',
};
const T = (text) => (LANG === 'tr' && TR[text]) || text;
document.documentElement.classList.add('js');

// The nine recorded points of the field: three feed settings by three space settings.
const FEED = [25, 50, 80];
const SPACE = [10, 40, 80];

const state = {
  sound: false,          // is sound wanted
  loading: false,
  failed: false,
  chain: 'dendrite',     // 'dry' or 'dendrite'
  mode: null,            // 'live' or 'recorded', decided when sound first starts (see 4. sound)
  fx: 50,                // place of the light on the field, in percent: across is space
  fy: 50,                //                                              up is feed
  fly: true,             // the itch: the fly may move the tape
};

// ---------------------------------------------------------------- 2. clock
//
// With sound on the position follows the audio clock, so drawing and sound stay together.
// With sound off it follows the page clock, so the drawing keeps running in silence.

const audio = {
  ctx: null,
  master: null,
  dryBus: null, dryOut: null, wetOut: null,
  engine: null,              // the AudioWorkletNode that runs dendrite, when live
  left: null, right: null,   // analysers for the stereo display
  takes: {},                 // name -> { buffer, gain, source, lead }
  hits: {},                  // name -> buffer
  playing: false,
  startedAt: 0,              // audio clock time when the loop started
  offset: 0,                 // loop position it started from
};

const loopSeconds = TAKE.seconds;
let pageEpoch = performance.now() / 1000;

function loopPosition(at) {
  const elapsed = audio.playing
    ? (at ?? audio.ctx.currentTime) - audio.startedAt + audio.offset
    : performance.now() / 1000 - pageEpoch;
  return ((elapsed % loopSeconds) + loopSeconds) % loopSeconds;
}

// Gives each event of the take once per loop. start(onEvent), stop().
// onEvent receives { x: 0..1, y: 0..1, energy: 0..1 }. A detector source would have the same shape.
function takeSource() {
  let last = loopPosition();
  let lastTick = performance.now();
  let timer = null;
  return {
    start(onEvent) {
      timer = setInterval(() => {
        const now = loopPosition();
        const tick = performance.now();
        const slept = tick - lastTick > 1500;            // the tab was in the background
        lastTick = tick;
        const wrapped = last - now > loopSeconds / 2;
        if (slept || (now < last && !wrapped)) { if (slept) last = now; return; }
        if (groove.running) { last = now; return; }      // live, the stabs draw themselves
        for (const ev of TAKE.events) {
          const due = wrapped ? ev.t > last || ev.t <= now : ev.t > last && ev.t <= now;
          if (due) onEvent(ev);
        }
        last = now;
      }, 25);
    },
    stop() { clearInterval(timer); },
  };
}

// ---------------------------------------------------------------- 3. branches
//
// (replaced 2026-11-23 by the afferent layer below; the old note follows for history)
// One event, one point of light. With dendrite in the chain the point grows its repeats,
// placed by the plug-in's own rule: two read heads, a dotted eighth and a quarter of the
// tempo, both feeding back, so every repeat splits in two. Down the page is time.
// Sideways is the stereo field: the dotted head keeps the side, the quarter head inverts
// it, and each generation sits one step further from where the event was.
// The drawing follows that rule. It is not measured from the audio.

const canvas = $('marks');
const pen = canvas?.getContext('2d');

// the tempo: fixed for the recordings, set by the reader when the engine runs live
const BPM_MIN = 80, BPM_MAX = 160;
let bpm = TAKE.bpm;
const heads = () => [
  { delay: (60 / bpm) * 0.75, flips: false },    // dotted eighth
  { delay: 60 / bpm, flips: true },              // quarter
];

// afferent: carrying signals inward, toward the brain.
// The background is that idea. The edges of the window are the body; the middle is the brain.
// Every touch, and every hit of the music, starts a spike where it lands (a receptor).
// The spike runs inward along a nerve, joins one of a few tracts that bundle the signals,
// and arrives at the centre, which answers with a flash and a ring.
// With dendrite in the chain the brain sends the signal round again at the plug-in's own
// delay times (a dotted eighth and a quarter), each pass fainter: the echo, drawn as nerve traffic.
// Nerves stay faint for a while after use, so the field records where it was touched.

const TRACTS = 7;                     // bundles the nerves join on their way in
const NERVE_LIFE = 9000;              // ms a used nerve stays visible
const RING_LIFE = 520;                // ms of the receptor ring at the touch
const CORE_LIFE = 820;                // ms of the centre's answer
let signals = [];                     // spikes in flight
let nerves = [];                      // paths, kept faint after use
let rings = [];                       // receptor rings and centre answers
let tractAngle0 = Math.random() * Math.PI * 2;
let blank = false;
let lastDraw = 0;
let coreGlow = 0;                     // the centre's afterglow, 0..1
const FRAME_MS = window.matchMedia('(pointer: coarse)').matches ? 32 : 15;

const W = () => window.innerWidth;
const H = () => window.innerHeight;
const centre = () => ({ x: W() / 2, y: H() * 0.47 });

// The layer covers the whole window, so its cost is its pixel count: up to 2 device pixels per css pixel.
function resizeCanvas() {
  const ratio = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.round(W() * ratio);
  canvas.height = Math.round(H() * ratio);
  pen.setTransform(ratio, 0, 0, ratio, 0, 0);
  blank = false;
}

// one point of light, drawn once and stamped
const SPRITE = 256;
const sprite = document.createElement('canvas');
sprite.width = sprite.height = SPRITE;
{
  const g = sprite.getContext('2d');
  const glow = g.createRadialGradient(SPRITE / 2, SPRITE / 2, 0, SPRITE / 2, SPRITE / 2, SPRITE / 2);
  glow.addColorStop(0, 'rgba(255, 255, 255, 1)');
  glow.addColorStop(0.06, 'rgba(250, 250, 250, 0.95)');
  glow.addColorStop(0.12, 'rgba(237, 237, 237, 0.45)');
  glow.addColorStop(0.25, 'rgba(237, 237, 237, 0.14)');
  glow.addColorStop(0.5, 'rgba(237, 237, 237, 0.04)');
  glow.addColorStop(1, 'rgba(237, 237, 237, 0)');
  g.fillStyle = glow;
  g.fillRect(0, 0, SPRITE, SPRITE);
}

// A nerve from (x, y) to the centre: a curved run to the nearest tract entry, then the tract inward.
// Sampled once into points with their running length, so a spike's place is a lookup.
function nervePath(x, y) {
  const c = centre();
  const reach = Math.min(W(), H());
  const angle = Math.atan2(y - c.y, x - c.x);
  const step = (Math.PI * 2) / TRACTS;
  const k = Math.round((angle - tractAngle0) / step);
  const ta = tractAngle0 + k * step;
  const tr = reach * 0.2;
  const tx = c.x + Math.cos(ta) * tr, ty = c.y + Math.sin(ta) * tr;
  const dx = tx - x, dy = ty - y, d = Math.hypot(dx, dy) || 1;
  const bend = (Math.random() - 0.5) * d * 0.45;               // no two nerves run the same way
  const cx = x + dx * 0.5 - (dy / d) * bend, cy = y + dy * 0.5 + (dx / d) * bend;
  const pts = [];
  const seg1 = Math.max(10, Math.round(d / 14));
  for (let i = 0; i <= seg1; i++) {
    const t = i / seg1, u = 1 - t;
    pts.push(u * u * x + 2 * u * t * cx + t * t * tx, u * u * y + 2 * u * t * cy + t * t * ty);
  }
  // the tract: a gentle curve into the centre, the same for every nerve that joins it
  const sx = c.x + Math.cos(ta + 0.35) * tr * 0.5, sy = c.y + Math.sin(ta + 0.35) * tr * 0.5;
  for (let i = 1; i <= 12; i++) {
    const t = i / 12, u = 1 - t;
    pts.push(u * u * tx + 2 * u * t * sx + t * t * c.x, u * u * ty + 2 * u * t * sy + t * t * c.y);
  }
  const lengths = [0];
  for (let i = 2; i < pts.length; i += 2) lengths.push(lengths[lengths.length - 1] + Math.hypot(pts[i] - pts[i - 2], pts[i + 1] - pts[i - 1]));
  return { pts, lengths, total: lengths[lengths.length - 1], used: performance.now(), level: 0 };
}

// the point at a fraction of a nerve's length
function along(nerve, f) {
  const target = f * nerve.total;
  const L = nerve.lengths;
  let i = 1;
  while (i < L.length - 1 && L[i] < target) i++;
  const span = L[i] - L[i - 1] || 1;
  const t = Math.max(0, Math.min(1, (target - L[i - 1]) / span));
  const p = nerve.pts;
  return [p[(i - 1) * 2] + (p[i * 2] - p[(i - 1) * 2]) * t, p[(i - 1) * 2 + 1] + (p[i * 2 + 1] - p[(i - 1) * 2 + 1]) * t];
}

// a spike along a nerve. It speeds up as it goes in (ease-in on the way, a hard landing at the centre).
function fire(nerve, strength, delayMs = 0, echo = 0) {
  const born = performance.now() + delayMs;
  const dur = Math.min(1250, 380 + nerve.total * 1.1);
  signals.push({ nerve, strength, born, dur, echo, landed: false });
  nerve.level = Math.max(nerve.level, strength);
  nerve.used = born + dur;
}

// x and y in pixels of the window; energy 0..1
function grow(x, y, energy) {
  const now = performance.now();
  const strength = 0.35 + Math.max(0, Math.min(1, energy)) * 0.65;
  rings.push({ x, y, born: now, life: RING_LIFE, r0: 3, r1: 22 + strength * 30, level: strength });
  const nerve = nervePath(x, y);
  nerves.push(nerve);
  if (nerves.length > 90) nerves.shift();
  fire(nerve, strength);
}

window.AFFERENT_GROW = (x, y, energy) => grow(x, y, energy);

// the kick is felt in the middle: the brain itself thumps, no nerve needed
document.addEventListener('afferent:beat', (e) => {
  if (!state.sound || e.detail?.kind !== 'kick') return;
  const c = centre();
  coreGlow = Math.min(1, coreGlow + 0.45);
  rings.push({ x: c.x, y: c.y, born: performance.now(), life: 620, r0: 10, r1: Math.min(W(), H()) * 0.16, level: 0.55 });
});

// a hit of the music: a receptor near the edge of the window, its side from the stereo place
function onEvent(ev) {
  if (!state.sound) return;                       // muted: the music is not drawn, so nothing looks like it still plays
  const x = (0.05 + ev.x * 0.9) * W();
  const top = ev.y < 0.5;
  const y = top ? H() * (0.08 + ev.y * 0.24) : H() * (0.7 + (ev.y - 0.5) * 0.44);
  grow(x, y, ev.energy * 0.8);
}

// resting activity: now and then a faint spike from somewhere at the edge, so the field is alive before anyone touches it
let nextRest = performance.now() + 1800;
function restingActivity(now) {
  if (reducedMotion || now < nextRest || document.hidden) return;
  nextRest = now + 2600 + Math.random() * 3200;
  if (signals.length > 6) return;
  const side = Math.floor(Math.random() * 4);
  const r = Math.random();
  const x = side === 0 ? W() * r : side === 1 ? W() * 0.97 : side === 2 ? W() * r : W() * 0.03;
  const y = side === 0 ? H() * 0.06 : side === 1 ? H() * r : side === 2 ? H() * 0.95 : H() * r;
  const nerve = nervePath(x, y);
  nerves.push(nerve);
  fire(nerve, 0.22);
}

const easeIn = (t) => t * t * (1.6 - 0.6 * t);              // accelerates inward, lands at full speed

function land(sig, now) {
  sig.landed = true;
  const c = centre();
  coreGlow = Math.min(1, coreGlow + sig.strength * 0.7);
  rings.push({ x: c.x, y: c.y, born: now, life: CORE_LIFE, r0: 6, r1: 34 + sig.strength * 60, level: sig.strength * 0.8 });
  // the echo: with dendrite on, the brain sends it round again at the plug-in's delay times
  if (state.chain === 'dendrite' && sig.echo < 3) {
    const [a, b] = heads();
    const head = sig.echo % 2 ? b : a;
    fire(sig.nerve, sig.strength * 0.55, head.delay * 1000, sig.echo + 1);
  }
}

function drawBranches(time) {
  requestAnimationFrame(drawBranches);
  if (time - lastDraw < FRAME_MS) return;        // 60 frames on a computer (a spike moves fast), 30 on a phone
  lastDraw = time;
  const now = performance.now();
  restingActivity(now);

  nerves = nerves.filter((n) => now - n.used < NERVE_LIFE);
  rings = rings.filter((r) => now - r.born < r.life);
  signals = signals.filter((s) => now - s.born < s.dur + 600);
  coreGlow *= 0.94;

  if (!nerves.length && !rings.length && !signals.length && coreGlow < 0.01) {
    if (!blank) pen.clearRect(0, 0, W(), H());
    blank = true;
    return;
  }
  blank = false;
  pen.clearRect(0, 0, W(), H());
  const quiet = main.dataset.page === 'text' ? 0.35 : 1;

  // the nerves: hairlines that fade after use
  pen.lineWidth = 0.7;
  pen.lineCap = 'round';
  pen.lineJoin = 'round';
  pen.strokeStyle = '#ededed';
  for (const n of nerves) {
    const age = Math.max(0, now - n.used) / NERVE_LIFE;
    const a = quiet * (0.08 + n.level * 0.3) * (1 - age) ** 1.4;
    if (a < 0.004) continue;
    pen.globalAlpha = a;
    pen.beginPath();
    pen.moveTo(n.pts[0], n.pts[1]);
    for (let i = 2; i < n.pts.length; i += 2) pen.lineTo(n.pts[i], n.pts[i + 1]);
    pen.stroke();
  }

  // the spikes: a bright head and a short tail drawn along the nerve behind it
  pen.lineWidth = 1.8;
  for (const s of signals) {
    const t = (now - s.born) / s.dur;
    if (t < 0) continue;
    if (t >= 1) { if (!s.landed) land(s, now); continue; }
    const f = easeIn(t);
    const tail = 0.16;
    pen.beginPath();
    const [x0, y0] = along(s.nerve, Math.max(0, f - tail));
    pen.moveTo(x0, y0);
    for (let k = 1; k <= 8; k++) { const [x, y] = along(s.nerve, Math.max(0, f - tail + (tail * k) / 8)); pen.lineTo(x, y); }
    pen.globalAlpha = quiet * Math.min(1, s.strength * 0.9);
    pen.stroke();
    const [hx, hy] = along(s.nerve, f);
    const size = 34 + s.strength * 56;
    pen.globalAlpha = quiet * Math.min(1, 0.35 + s.strength);
    pen.drawImage(sprite, hx - size / 2, hy - size / 2, size, size);
  }

  // rings: where a touch lands (the receptor answers at once) and where a spike arrives
  pen.lineWidth = 1.2;
  for (const r of rings) {
    const t = (now - r.born) / r.life;
    const e = 1 - (1 - t) ** 3;                    // ease-out: the ring is already wide on the first frame
    pen.globalAlpha = quiet * Math.min(1, r.level * 1.1) * (1 - t) ** 1.5;
    pen.beginPath();
    pen.arc(r.x, r.y, r.r0 + (r.r1 - r.r0) * e, 0, Math.PI * 2);
    pen.stroke();
  }

  // the centre: a small light that glows with what has arrived
  if (coreGlow > 0.01) {
    const c = centre();
    const size = 40 + coreGlow * 120;
    pen.globalAlpha = quiet * Math.min(0.9, coreGlow);
    pen.drawImage(sprite, c.x - size / 2, c.y - size / 2, size, size);
  }
  pen.globalAlpha = 1;
}

// dragging over the background with a mouse lays down a run of receptors (shift is left free for the tempo)
{
  let last = null;
  document.addEventListener('pointerdown', (e) => {
    if (e.pointerType !== 'mouse' || e.button !== 0 || e.shiftKey || !isGround(e.target)) return;
    last = { x: e.clientX, y: e.clientY };
  });
  document.addEventListener('pointermove', (e) => {
    if (!last || e.shiftKey || !(e.buttons & 1)) { last = null; return; }
    if (Math.hypot(e.clientX - last.x, e.clientY - last.y) < 46) return;
    last = { x: e.clientX, y: e.clientY };
    grow(e.clientX, e.clientY, 0.25);
  });
  document.addEventListener('pointerup', () => { last = null; });
}

// ---------------------------------------------------------------- 4. sound
//
// Two ways to hear dendrite, chosen when sound is first turned on:
//
//   live      the plug-in's engine itself runs in the page (assets/dendrite.wasm, compiled
//             from the plug-in's DSP source without changes, inside an AudioWorklet).
//             a dub chord stab is played in the page (assets/stab.js) and passes through
//             it. the field sets feed and space, the reader sets the tempo.
//   recorded  where the engine cannot run, or the device is too slow for it, the page plays
//             recordings made with the same engine: nine loops, one per point of the field.
//
// The recordings were made from the same stab, at 120 bpm (tools/render_stab.js).

const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
const cellPlace = (index) => 18 + index * 32;                 // percent across the field
const cellIndex = (place) => clamp(Math.round((place - 18) / 32), 0, 2);

// the setting at a place on the field: a straight line through the three recorded settings
function valueAt(place, settings) {
  const t = (place - 18) / 32;
  const v = t <= 1 ? settings[0] + (settings[1] - settings[0]) * t : settings[1] + (settings[2] - settings[1]) * (t - 1);
  return clamp(v, 0, 100);
}
const feedNow = () => valueAt(state.fy, FEED);
const spaceNow = () => valueAt(state.fx, SPACE);
// the default point also has a take with the fly off, aligned with the one with it on
const activeTake = () => {
  if (state.chain === 'dry') return 'dry';
  const name = `f${cellIndex(state.fy)}s${cellIndex(state.fx)}`;
  return !state.fly && name === 'f1s1' ? 'f1s1-off' : name;
};

function base64ToArrayBuffer(text) {
  const binary = atob(text);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

// a file from assets/. the preview build carries some files inside itself.
async function loadBytes(path) {
  if (EMBED?.data[path]) return base64ToArrayBuffer(EMBED.data[path]);
  const response = await fetch(EMBED ? `assets/${path}` : `/assets/${path}${VERSION}`);
  if (!response.ok) throw new Error(`${response.status} for ${path}`);
  return response.arrayBuffer();
}

const loadBuffer = async (name) => audio.ctx.decodeAudioData(await loadBytes(`audio/${name}.mp3`));

function buildGraph() {
  const AudioCtx = window.AudioContext ?? window.webkitAudioContext;
  const ctx = (audio.ctx = new AudioCtx());
  audio.master = ctx.createGain();
  audio.master.gain.value = 0;
  audio.master.connect(ctx.destination);
  audio.dryBus = ctx.createGain();              // everything that has not been through dendrite
  audio.duck = ctx.createGain();                // the stab track after dendrite: the kick ducks it 4 dB
  audio.duck.connect(audio.master);
  audio.kickBus = ctx.createGain();             // the kick: dry, never through dendrite
  audio.kickBus.connect(audio.master);

  const split = ctx.createChannelSplitter(2);
  audio.left = ctx.createAnalyser();
  audio.right = ctx.createAnalyser();
  audio.left.fftSize = audio.right.fftSize = 1024;
  audio.master.connect(split);
  split.connect(audio.left, 0);
  split.connect(audio.right, 1);
}

// Tries to start the engine in the page. Resolves to true when it runs fast enough.
async function startEngine() {
  const ctx = audio.ctx;
  try {
    if (!ctx.audioWorklet || !window.WebAssembly) return false;
    const wasm = await loadBytes('dendrite.wasm');
    // the worklet script is a file on the site. the preview carries it inside itself and
    // tries the ways a sandboxed page may be allowed to load it.
    const ways = EMBED
      ? [`data:text/javascript;base64,${btoa(EMBED.worklet)}`,
         URL.createObjectURL(new Blob([EMBED.worklet], { type: 'text/javascript' })),
         'assets/dendrite-worklet.js']
      : [`/assets/dendrite-worklet.js${VERSION}`];
    let loaded = false;
    for (const url of ways) {
      try { await ctx.audioWorklet.addModule(url); loaded = true; break; } catch (error) { console.warn(error); }
    }
    if (!loaded) return false;
    const node = new AudioWorkletNode(ctx, 'dendrite', {
      numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [2],
      channelCount: 2, channelCountMode: 'explicit',
      processorOptions: { wasm, bpm: TAKE.bpm },
    });
    const cost = await new Promise((resolve, reject) => {
      node.port.onmessage = (e) => resolve(e.data.cost);
      node.onprocessorerror = () => reject(new Error('the engine stopped'));
      setTimeout(() => reject(new Error('the engine did not start')), 20000);
    });
    console.info(`afferent: the engine needs ${Math.round(cost * 100)}% of real time on this device`);
    // the audio thread also mixes everything else; above about a third of real time a slow
    // or busy device starts to drop out, so it uses the recordings instead
    if (cost > 0.35) return false;

    audio.engine = node;
    audio.dryOut = ctx.createGain();
    audio.wetOut = ctx.createGain();
    audio.dryOut.gain.value = audio.wetOut.gain.value = 0;
    audio.dryBus.connect(audio.dryOut).connect(audio.duck);
    audio.dryBus.connect(node).connect(audio.wetOut).connect(audio.duck);
    return true;
  } catch (error) {
    console.warn('afferent: the engine could not start, using recordings.', error);
    return false;
  }
}

// The live part: stabs scheduled a little ahead on a beat clock. The engine is told the same
// clock (anchor), so its tempo grid, and the fly's, sit exactly on the stabs.
const groove = { running: false, seq: null, next: null, last: null, t0: 0, beat0: 0, timer: null };
const beatAt = (t) => groove.beat0 + ((t - groove.t0) * bpm) / 60;
const timeAtBeat = (b) => groove.t0 + ((b - groove.beat0) * 60) / bpm;

function anchorEngine() {
  audio.engine?.port.postMessage({ anchor: { time: groove.t0, beat: groove.beat0, bpm } });
}

// each event is a stab (into dendrite) or a kick (dry, and it ducks the stab track).
// a page can listen for 'afferent:beat' on document: detail { kind, chord, bar, throw }.
function scheduleGroove() {
  const ctx = audio.ctx;
  for (;;) {
    const event = groove.next;
    const when = timeAtBeat(event.step / 4) + event.timing;
    if (when > ctx.currentTime + 0.15) break;
    if (when >= ctx.currentTime) {
      const wait = (when - ctx.currentTime) * 1000;
      if (event.kind === 'kick') {
        STAB.kick(ctx, audio.kickBus, when, event);
        STAB.duck(audio.duck.gain, when);
      } else {
        STAB.play(ctx, audio.dryBus, when, event);
        groove.last = event;
        setTimeout(() => groove.running && onEvent({ x: event.x, y: event.y, energy: (event.velocity - 0.5) * 2 }), wait);
      }
      setTimeout(() => groove.running && document.dispatchEvent(new CustomEvent('afferent:beat',
        { detail: { kind: event.kind, chord: event.chord, bar: event.bar, throw: !!event.throw } })), wait);
    }
    groove.next = groove.seq.next();
  }
}

// every play starts the part from its first bar: four bars of stabs, then the kick comes in
function startGroove(when) {
  groove.seq = STAB.create(Date.now());
  groove.next = groove.seq.next();
  groove.last = null;
  groove.t0 = when;
  groove.beat0 = 0;
  groove.running = true;
  anchorEngine();
  scheduleGroove();
  groove.timer = setInterval(scheduleGroove, 25);
}

// mute stops the part itself: no more events are made, and dendrite's echo is cleared,
// so nothing is left ringing (or still being generated) when sound comes back
function stopGroove() {
  clearInterval(groove.timer);
  groove.running = false;
  groove.seq = groove.next = null;
  setTimeout(() => audio.engine?.port.postMessage({ reset: true }), 300);   // after the 0.25 s fade
}

function setTempo(value) {
  const next = clamp(Math.round(value), BPM_MIN, BPM_MAX);           // whole numbers only (Hakan, 23 nov)
  if (next === bpm) return;
  if (groove.running) {                       // the beat carries on from here at the new tempo
    const now = audio.ctx.currentTime;
    groove.beat0 = beatAt(now);
    groove.t0 = now;
  }
  bpm = next;
  anchorEngine();
  render();
}

function sendControls(more = {}) {
  audio.engine?.port.postMessage({ feed: feedNow() / 100, space: spaceNow() / 100, fly: state.fly, ...more });
}

function ramp(param, target, seconds) {
  const now = audio.ctx.currentTime;
  param.cancelScheduledValues(now);
  param.setValueAtTime(param.value, now);
  param.linearRampToValueAtTime(target, now + seconds);
}

// Loads one recording (once) and, if the loop is running, starts it in step with the others.
function ensureTake(name) {
  const known = audio.takes[name];
  if (known) return known.ready;
  const take = (audio.takes[name] = { buffer: null, gain: null, source: null, lead: 0, ready: null });
  take.ready = loadBuffer(name).then((buffer) => {
    take.buffer = buffer;
    // some browsers keep the encoder's 23 ms of silence at the start of an mp3
    take.lead = buffer.duration - loopSeconds > 0.04 ? 0.023 : 0;
    take.gain = audio.ctx.createGain();
    take.gain.gain.value = 0;
    take.gain.connect(name === 'dry' ? audio.dryBus : audio.master);
    if (audio.playing) startTake(take, audio.ctx.currentTime + 0.06);
  });
  take.ready.catch(() => { delete audio.takes[name]; });
  return take.ready;
}

function startTake(take, when) {
  const source = audio.ctx.createBufferSource();
  source.buffer = take.buffer;
  source.loop = true;
  source.loopStart = take.lead;
  source.loopEnd = Math.min(take.buffer.duration, take.lead + loopSeconds);
  source.connect(take.gain);
  source.start(when, take.lead + loopPosition(when));
  take.source = source;
}

function applyMix(seconds = 0.12) {
  const wet = state.chain === 'dendrite';
  if (state.mode === 'live') {
    ramp(audio.dryOut.gain, wet ? 0 : 1, seconds);
    ramp(audio.wetOut.gain, wet ? 1 : 0, seconds);
    return;
  }
  const active = activeTake();
  for (const [name, take] of Object.entries(audio.takes)) {
    if (take.gain) ramp(take.gain.gain, name === active ? 1 : 0, seconds);
  }
}

function startLoop() {
  const offset = loopPosition();                 // continue from where the drawing is
  const when = audio.ctx.currentTime + 0.06;
  audio.startedAt = when;
  audio.offset = offset;
  audio.playing = true;
  if (state.mode === 'live') startGroove(when);
  for (const take of Object.values(audio.takes)) if (take.buffer) startTake(take, when);
  ramp(audio.master.gain, 1, 0.5);
}

function stopLoop() {
  if (!audio.playing) return;
  pageEpoch = performance.now() / 1000 - loopPosition();       // the drawing carries on from here
  audio.playing = false;
  stopGroove();
  ramp(audio.master.gain, 0, 0.25);
  const old = Object.values(audio.takes).map((take) => take.source).filter(Boolean);
  for (const take of Object.values(audio.takes)) take.source = null;
  setTimeout(() => {
    old.forEach((source) => source.stop());
    if (!state.sound) audio.ctx.suspend();
  }, 350);
}

async function soundOn() {
  if (state.sound) return;
  state.sound = true;
  state.failed = false;
  document.body.classList.add('heard');
  if (!audio.ctx) buildGraph();                  // must happen inside the click or key press
  audio.ctx.resume();

  state.loading = true;
  render();
  try {
    if (!state.mode) {
      state.mode = (await startEngine()) ? 'live' : 'recorded';
      if (state.mode === 'recorded') {
        audio.dryBus.connect(audio.master);
        state.fx = cellPlace(cellIndex(state.fx));           // recordings exist only at the nine points
        state.fy = cellPlace(cellIndex(state.fy));
      }
    }
    if (state.mode === 'recorded') {
      await ensureTake('dry');
      await ensureTake(activeTake());
    } else sendControls();
  } catch (error) {
    console.error(error);
    state.sound = false;
    state.failed = true;
  }
  state.loading = false;

  if (state.sound && !audio.playing) {
    applyMix(0);
    startLoop();
  }
  render();
  say(state.failed ? T('sound unavailable') : state.sound ? `${T('sound on')}, ${state.chain}` : T('sound off'));
}

function soundOff() {
  if (!state.sound) return;
  state.sound = false;
  stopLoop();
  render();
  say(T('sound off'));
}

// Changes the chain or the place on the field.
async function choose(change) {
  Object.assign(state, change);
  if (state.mode === 'recorded') {
    state.fx = cellPlace(cellIndex(state.fx));
    state.fy = cellPlace(cellIndex(state.fy));
  }
  render();
  if (!state.sound) return soundOn();
  if (state.loading) return;
  if (state.mode === 'live') {
    sendControls();
    return applyMix();
  }
  const wanted = activeTake();
  try { await ensureTake(wanted); } catch (error) { console.error(error); return; }
  if (wanted === activeTake()) applyMix();
}

// A single stab, played where the reader taps. Five pitches; higher on the page is higher.
// Live, it is the stab itself, through the engine. Otherwise a recording of it through it.
const HIT_TRANSPOSE = [-7, -4, 0, 3, 7];   // the recordings' names (hit0..4); live, the same five places play
const HIT_INVERSION = [-2, -1, 0, 1, 2];   // the chord playing now, lower or higher inversions: always in key
async function playHit(pitch) {
  const live = state.mode === 'live';
  if (live) {
    const stab = { ...(groove.last ?? STAB.create(1).next()), timing: 0, kind: 'stab' };
    if (stab.throw) stab.decay /= 1.9;
    STAB.play(audio.ctx, audio.dryBus, audio.ctx.currentTime + 0.005, stab, HIT_INVERSION[pitch]);
    return;
  }
  const name = live ? `hit${pitch}-dry` : `hit${pitch}-${state.chain}`;
  try {
    audio.hits[name] ??= loadBuffer(name);
    const buffer = await audio.hits[name];
    if (!audio.playing) return;
    const source = audio.ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(live ? audio.dryBus : audio.master);
    source.start();
  } catch (error) {
    delete audio.hits[name];
    console.warn(error);
  }
}

// ---------------------------------------------------------------- 5. controls
//
//   data-action="sound"            toggles sound
//   data-action="dry"              takes dendrite out of the chain (and starts sound)
//   data-action="dendrite"         puts dendrite in the chain (and starts sound)
//   data-feed="1" data-space="2"   one of the nine points of the field
//   data-when="sound"              an element shown only while sound is on
//   data-when="silence"            ... only while it is off
//   data-label                     text inside a sound control; data-on / data-off set its words

function render() {
  const on = state.sound && !state.loading;
  for (const el of $$('[data-action="sound"]')) {
    el.setAttribute('aria-pressed', String(on));
    el.dataset.state = state.loading ? 'loading' : '';
    const label = el.querySelector('[data-label]');
    if (label) {
      label.textContent = state.failed ? T('sound unavailable')
        : state.loading ? T('loading')
        : on ? (label.dataset.on ?? T('sound')) : (label.dataset.off ?? T('sound'));
    }
  }
  for (const name of ['dry', 'dendrite']) {
    for (const el of $$(`[data-action="${name}"]`)) el.setAttribute('aria-pressed', String(on && state.chain === name));
  }
  for (const el of $$('[data-action="fly-on"]')) el.setAttribute('aria-pressed', String(state.fly));
  for (const el of $$('[data-action="fly-off"]')) el.setAttribute('aria-pressed', String(!state.fly));
  // the a/b panel's own label follows the switch, not the recording (whose burned-in label is covered)
  for (const el of $$('[data-fly-label]')) el.textContent = state.fly ? 'fly: on' : 'fly: off';
  for (const el of $$('[data-when="sound"]')) el.hidden = !on;
  for (const el of $$('[data-when="silence"]')) el.hidden = on;
  for (const el of $$('[data-when="live"]')) el.hidden = !(on && state.mode === 'live');
  for (const el of $$('[data-bpm]')) el.textContent = String(bpm);

  for (const el of $$('.cell')) {
    const here = cellPlace(Number(el.dataset.feed)) === state.fy && cellPlace(Number(el.dataset.space)) === state.fx;
    el.setAttribute('aria-pressed', String(here && state.chain === 'dendrite'));
  }
  const light = $('light');
  if (light) {
    light.style.left = `${state.fx}%`;
    light.style.top = `${100 - state.fy}%`;
    light.style.opacity = state.chain === 'dendrite' ? 1 : 0.25;
  }
  const readout = $('readout');
  if (readout) readout.textContent = `feed ${Math.round(feedNow())}   space ${Math.round(spaceNow())}`;
  const note = $('engine-note');
  if (note) {
    note.textContent = T(state.mode === 'live' ? 'the engine of dendrite is running in this page. drag the light. hold the dark to throw.'
      : state.mode === 'recorded' ? 'nine recordings made with the engine of dendrite, one per point. drag the light.'
      : 'drag the light.');
  }
}

function say(text) {
  const live = $('live');
  if (live) live.textContent = text;
}

// ---------------------------------------------------------------- download sheet
//
// One sheet on every page. It puts the file for this visitor's system first.

function systemOf() {
  const ua = navigator.userAgent;
  const platform = (navigator.userAgentData?.platform || navigator.platform || '').toLowerCase();
  if (/iphone|ipad|ipod|android/i.test(ua)) return 'mobile';
  if (platform.includes('mac') || /mac os x/i.test(ua)) return 'mac';
  if (platform.includes('win') || /windows/i.test(ua)) return 'windows';
  if (platform.includes('linux') || /linux|x11/i.test(ua)) return 'linux';
  return 'other';
}

const SYSTEM_MAIN = {
  windows: ['windows installer', '7.2 mb. puts dendrite.vst3 in the system vst3 folder.'],
  mac: ['download for macos', '23.2 mb. vst3 and au, apple silicon and intel. not code-signed: allow it once.'],
  linux: ['download for linux', '7.0 mb. vst3.'],
};

function openSheet() {
  const sheet = $('sheet');
  if (!sheet?.showModal) { go(LANG === 'tr' ? '/tr/s-001/' : '/s-001/', 'get'); return; }
  const system = systemOf();
  const row = sheet.querySelector(`[data-os="${system}"]`);
  const first = $('sheet-main');
  const note = $('sheet-note');
  for (const li of sheet.querySelectorAll('[data-os]')) li.classList.toggle('here', li === row);
  if (row && SYSTEM_MAIN[system]) {
    first.hidden = false;
    first.href = row.querySelector('a').href;
    first.textContent = T(SYSTEM_MAIN[system][0]);
    note.textContent = T(SYSTEM_MAIN[system][1]);
  } else {
    first.hidden = true;
    note.textContent = T(system === 'mobile'
      ? 'dendrite runs on a computer. open afferent.page there, or pick a file below.'
      : 'pick the file for your system.');
  }
  sheet.showModal();
}

function closeSheet() { $('sheet')?.close(); }

$('sheet')?.addEventListener('click', (e) => {
  if (e.target === e.currentTarget) closeSheet();                 // a click on the backdrop
  else if (e.target.closest('a[href^="/"]')) closeSheet();        // a page link inside it
});

// ---------------------------------------------------------------- chapter rail (home)

const rail = document.querySelector('.rail');
const chapterWatch = new IntersectionObserver((entries) => {
  for (const entry of entries) {
    if (!entry.isIntersecting) continue;
    for (const a of rail.querySelectorAll('a')) a.setAttribute('aria-current', String(a.dataset.to === entry.target.dataset.chapter));
  }
}, { rootMargin: '-45% 0px -45% 0px' });

function buildRail() {
  if (!rail) return;
  chapterWatch.disconnect();
  const chapters = $$('main [data-chapter]');
  rail.hidden = chapters.length === 0;
  rail.innerHTML = '';
  for (const section of chapters) {
    const a = document.createElement('a');
    a.href = '#';
    a.dataset.to = section.dataset.chapter;
    a.innerHTML = `<span>${T(section.dataset.chapter)}</span>`;
    a.setAttribute('aria-label', T(section.dataset.chapter));
    a.addEventListener('click', (e) => { e.preventDefault(); e.stopImmediatePropagation(); section.scrollIntoView({ block: 'start' }); });
    rail.append(a);
    chapterWatch.observe(section);
  }
}

function act(action) {
  if (action === 'get') return openSheet();
  if (action === 'close') return closeSheet();
  if (action === 'sound') return state.sound ? soundOff() : soundOn();
  // the hero's listen: the sound starts inside this click, then the page moves to the a/b screen
  if (action === 'listen') {
    if (!state.sound) soundOn();
    const listen = $('listen');
    if (listen) { listen.scrollIntoView({ block: 'start' }); listen.focus({ preventScroll: true }); }
    return;
  }
  if (action === 'dry' || action === 'dendrite') return choose({ chain: action });
  if (action === 'fly-on' || action === 'fly-off') return choose({ fly: action === 'fly-on' });
  if (action === 'slower') return setTempo(bpm - 1);
  if (action === 'faster') return setTempo(bpm + 1);
}

// holding slower or faster keeps going, quicker the longer it is held
document.addEventListener('pointerdown', (e) => {
  const button = e.target.closest('[data-action="slower"], [data-action="faster"]');
  if (!button || e.button !== 0) return;
  let wait = 380, timer = null;
  const again = () => { act(button.dataset.action); wait = Math.max(40, wait * 0.8); timer = setTimeout(again, wait); };
  timer = setTimeout(again, wait);
  const release = () => { clearTimeout(timer); window.removeEventListener('pointerup', release); window.removeEventListener('pointercancel', release); };
  window.addEventListener('pointerup', release);
  window.addEventListener('pointercancel', release);
});

// Shift + drag, anywhere: the tempo, one bpm at a time (whole numbers: 119, 120, 121).
// right or up is faster. 12 px per bpm, so a slow hand lands on exactly the number it wants.
// listens on document: pointerdown (capture), then pointermove / pointerup / pointercancel on window,
// and swallows the click that ends the drag. only while the engine plays live.
const TEMPO_PX = 12;
document.addEventListener('pointerdown', (e) => {
  if (!e.shiftKey || e.button !== 0 || !(state.sound && state.mode === 'live')) return;
  if (e.target.closest('a, input, textarea, select')) return;
  e.preventDefault();
  e.stopImmediatePropagation();
  const x0 = e.clientX, y0 = e.clientY, from = bpm;
  document.body.classList.add('tempo-drag');
  const move = (m) => setTempo(from + Math.trunc((m.clientX - x0 - (m.clientY - y0)) / TEMPO_PX));
  const end = () => {
    document.body.classList.remove('tempo-drag');
    window.removeEventListener('pointermove', move);
    window.removeEventListener('pointerup', end);
    window.removeEventListener('pointercancel', end);
    const swallow = (c) => { c.preventDefault(); c.stopImmediatePropagation(); };
    window.addEventListener('click', swallow, { capture: true, once: true });
    setTimeout(() => window.removeEventListener('click', swallow, { capture: true }), 0);
  };
  window.addEventListener('pointermove', move);
  window.addEventListener('pointerup', end);
  window.addEventListener('pointercancel', end);
}, { capture: true });

const isGround = (target) => !target.closest('a, button, video, .square, .top, .player, .sheet, .rail, .specimen, .grid');

document.addEventListener('click', (e) => {
  const control = e.target.closest('[data-action]');
  if (control) {
    if (control.tagName === 'A') {
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;   // let a new tab open the link
      e.preventDefault();
      e.stopImmediatePropagation();
    }
    return act(control.dataset.action);
  }
  const cell = e.target.closest('.cell');
  if (cell) {
    return choose({ chain: 'dendrite', fy: cellPlace(Number(cell.dataset.feed)), fx: cellPlace(Number(cell.dataset.space)) });
  }
  // a tap on empty ground: a point of light, and a stab if sound is on
  if (!isGround(e.target)) return;
  grow(e.clientX, e.clientY, 0.6);
  if (state.sound && audio.playing) playHit(clamp(Math.floor((1 - e.clientY / window.innerHeight) * 5), 0, 4));
});

// holding the ground is throw, as in the plug-in window: the input is sent into the loop harder
document.addEventListener('pointerdown', (e) => {
  if (state.mode !== 'live' || !audio.playing || !isGround(e.target)) return;
  sendControls({ throwHeld: 1 });
  const release = () => {
    sendControls({ throwHeld: 0 });
    window.removeEventListener('pointerup', release);
    window.removeEventListener('pointercancel', release);
  };
  window.addEventListener('pointerup', release);
  window.addEventListener('pointercancel', release);
});

// keys: s toggles sound, d switches between dry and dendrite
document.addEventListener('keydown', (e) => {
  if (e.metaKey || e.ctrlKey || e.altKey || e.repeat) return;
  if (e.target.closest('input, textarea, select, [contenteditable]')) return;
  if (e.key === 's') act('sound');
  if (e.key === 'd' && state.sound) act(state.chain === 'dry' ? 'dendrite' : 'dry');
});

// ---------------------------------------------------------------- 6. stereo
//
// Draws what is playing right now: each sample pair is one dot. Up is mid (left + right),
// sideways is side (left - right). A mono signal is a vertical line; width is stereo.

const samplesL = new Float32Array(1024);
const samplesR = new Float32Array(1024);

// drawn only while it is on screen; watched without reading the layout every frame
let scopeVisible = false;
let watchedScope = null;
const scopeWatch = new IntersectionObserver((entries) => {
  for (const entry of entries) scopeVisible = entry.isIntersecting;
});
function watchScope() {
  const scope = $('scope');
  if (scope === watchedScope) return;
  if (watchedScope) scopeWatch.unobserve(watchedScope);
  watchedScope = scope;
  scopeVisible = false;
  if (scope) scopeWatch.observe(scope);
}

function drawStereo() {
  const scope = $('scope');
  if (scope && audio.left && scopeVisible) {
    const size = scope.clientWidth;
    const ratio = Math.min(window.devicePixelRatio || 1, 1.5);
    if (scope.width !== Math.round(size * ratio)) scope.width = scope.height = Math.round(size * ratio);
    const ink = scope.getContext('2d');
    ink.setTransform(ratio, 0, 0, ratio, 0, 0);
    ink.globalAlpha = 1;
    ink.fillStyle = 'rgba(0, 0, 0, 0.16)';             // older dots fade instead of vanishing
    ink.fillRect(0, 0, size, size);
    if (audio.playing) {
      audio.left.getFloatTimeDomainData(samplesL);
      audio.right.getFloatTimeDomainData(samplesR);
      ink.fillStyle = '#ededed';
      ink.globalAlpha = 0.7;
      const gain = size * 2.4;
      for (let i = 0; i < samplesL.length; i += 2) {
        const mid = (samplesL[i] + samplesR[i]) / 2;
        const side = (samplesL[i] - samplesR[i]) / 2;
        ink.fillRect(size / 2 + side * gain * 2, size / 2 - mid * gain, 1.5, 1.5);
      }
    }
  }
  requestAnimationFrame(drawStereo);
}

// ---------------------------------------------------------------- 7. field and window
//
// The field: feed upward, space to the right. Live, the light can sit anywhere and sets the
// engine's two controls. With recordings it moves between the nine recorded points.

document.addEventListener('pointerdown', (e) => {
  const field = e.target.closest('.field');
  if (!field || e.button !== 0) return;
  const move = (ev) => {
    const box = field.getBoundingClientRect();
    choose({
      chain: 'dendrite',
      fx: clamp(((ev.clientX - box.left) / box.width) * 100, 6, 94),
      fy: clamp((1 - (ev.clientY - box.top) / box.height) * 100, 6, 94),
    });
  };
  const end = () => {
    field.classList.remove('dragging');
    window.removeEventListener('pointermove', move);
    window.removeEventListener('pointerup', end);
    window.removeEventListener('pointercancel', end);
  };
  field.classList.add('dragging');
  window.addEventListener('pointermove', move);
  window.addEventListener('pointerup', end);
  window.addEventListener('pointercancel', end);
  if (!e.target.closest('.cell')) move(e);             // a press between points also counts
});

// Videos of the plug-in window. They are silent and play only while on screen.
// The one marked data-follow="loop" was recorded over exactly one pass of the loop,
// so it is kept at the loop position: what the window shows is what is being heard.
const onScreen = new IntersectionObserver((entries) => {
  for (const { target, isIntersecting } of entries) {
    if (isIntersecting) target.play().catch(() => {});   // muted content loops: they play even with reduced motion
    else target.pause();
  }
}, { threshold: 0.3 });           // starts while it slides in, so a fast swipe lands on a moving clip

function wireVideos() {
  for (const video of $$('video[data-video]')) {
    const file = `video/${video.dataset.video}.mp4`;
    if (!video.src) video.src = EMBED?.data[file] ? `data:video/mp4;base64,${EMBED.data[file]}` : `${EMBED ? '' : '/'}assets/${file}${EMBED ? '' : VERSION}`;   // stamped: /assets/video is cached for 7 days
    // data-start: the second the clip opens on, so neighbouring screens show different views
    if (video.dataset.start && !video.dataset.started) {
      video.dataset.started = '1';
      const seek = () => { video.currentTime = Number(video.dataset.start); };
      if (video.readyState >= 1) seek(); else video.addEventListener('loadedmetadata', seek, { once: true });
    }
    onScreen.observe(video);
  }
}

setInterval(() => {
  for (const video of $$('video[data-follow="loop"]')) {
    if (video.paused || video.readyState < 2) continue;
    // a small drift is taken up by playing a little faster or slower; only a large one seeks,
    // because seeking a video makes it stall while it decodes from the previous key frame
    const length = video.duration || loopSeconds;
    let drift = (loopPosition() % length) - video.currentTime;
    if (drift > length / 2) drift -= length;
    if (drift < -length / 2) drift += length;
    if (Math.abs(drift) > 1.5) {
      video.currentTime = loopPosition() % length;
      video.playbackRate = 1;
    } else {
      video.playbackRate = Math.abs(drift) < 0.05 ? 1 : 1 + Math.max(-0.08, Math.min(0.08, drift / 2));
    }
  }
}, 700);

// ---------------------------------------------------------------- 8. pages
//
// Every page is a real file and works alone. When this script runs, a click on an
// internal link fetches the next page and replaces only <main>, so the drawing and the
// sound continue. The address, the title and the back button behave as usual.

function pathOf(href) {
  const url = new URL(href, location.href);
  return { path: url.pathname.replace(/index\.html$/, ''), anchor: url.hash.slice(1) };
}

// in the preview build the pages are inside the file and the address is a plain #name
let currentPath = EMBED
  ? (location.hash.length > 1 ? `/${location.hash.slice(1)}/` : '/')
  : pathOf(location.href).path;

async function readPage(path) {
  if (EMBED) return EMBED.pages[path] ?? null;
  const response = await fetch(path);
  if (!response.ok) return null;
  const doc = new DOMParser().parseFromString(await response.text(), 'text/html');
  const next = doc.querySelector('main');
  return next ? { title: doc.title, kind: next.dataset.page, html: next.innerHTML } : null;
}

const seen = new IntersectionObserver((entries) => {
  for (const entry of entries) {
    if (entry.isIntersecting) { entry.target.classList.add('in'); seen.unobserve(entry.target); }
  }
}, { threshold: 0.15 });

function arrive() {
  for (const el of $$('.reveal')) seen.observe(el);
  watchScope();
  wireVideos();
  buildRail();
  for (const link of $$('.top a')) {
    if (pathOf(link.getAttribute('href')).path === currentPath) link.setAttribute('aria-current', 'page');
    else link.removeAttribute('aria-current');
  }
  render();
  window.AFFERENT_ALIVE?.arrive();
}

function show(page, path, anchor) {
  document.title = page.title;
  main.dataset.page = page.kind;
  main.innerHTML = page.html;
  currentPath = path;
  arrive();
  const target = anchor && $(anchor);
  if (target) target.scrollIntoView({ behavior: 'instant' });
  else window.scrollTo({ top: 0, behavior: 'instant' });
  main.focus({ preventScroll: true });
}

async function go(path, anchor, { push = true } = {}) {
  // the page is read while the old one leaves (assets/alive.js: each destination leaves differently)
  const [page, kind] = await Promise.all([
    readPage(path).catch((error) => { console.warn(error); return null; }),
    window.AFFERENT_ALIVE?.leave(currentPath, path),
  ]);
  if (!page) {
    if (!EMBED) location.href = path;            // let the browser load it the ordinary way
    else window.AFFERENT_ALIVE?.enter(null);
    return;
  }
  // a short cross-fade between pages where the browser can do it
  if (document.startViewTransition && !reducedMotion && !window.AFFERENT_ALIVE) document.startViewTransition(() => show(page, path, anchor));
  else show(page, path, anchor);
  window.AFFERENT_ALIVE?.enter(kind);
  if (!push) return;
  if (EMBED) location.hash = path.replace(/\//g, '');
  else history.pushState({}, '', path + (anchor ? `#${anchor}` : ''));
}

document.addEventListener('click', (e) => {
  const link = e.target.closest('a[href]');
  if (!link || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
  if (link.target || link.hasAttribute('download') || link.hasAttribute('hreflang')) return;
  // pages with their own stylesheet (specification, legal) load the ordinary way
  if (link.hasAttribute('data-reload')) return;
  const href = link.getAttribute('href');

  if (href.startsWith('#')) {                    // a section on this page
    const target = $(href.slice(1));
    if (!target) return;
    e.preventDefault();
    target.scrollIntoView();
    target.focus({ preventScroll: true });
    return;
  }
  if (!href.startsWith('/')) return;             // another site: leave it alone

  e.preventDefault();
  const { path, anchor } = pathOf(href);
  if (path === currentPath) {
    const target = anchor && $(anchor);
    if (target) target.scrollIntoView();
    else window.scrollTo(0, 0);
    return;
  }
  go(path, anchor);
});

if (EMBED) {
  window.addEventListener('hashchange', () => {
    const name = location.hash.slice(1);
    const path = name ? `/${name}/` : '/';
    if (path !== currentPath) go(path, '', { push: false });
  });
  go(currentPath in EMBED.pages ? currentPath : '/', '', { push: false });
} else {
  window.addEventListener('popstate', () => {
    const { path, anchor } = pathOf(location.href);
    if (path !== currentPath) go(path, anchor, { push: false });
  });
}

// ---------------------------------------------------------------- start

arrive();
if (canvas && pen) {
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();
  takeSource().start(onEvent);
  requestAnimationFrame(drawBranches);
  requestAnimationFrame(drawStereo);
}
