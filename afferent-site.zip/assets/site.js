// afferent. one script for every page.
//
//   1. take      the loop: a list of events, and recordings of them (dry, and through dendrite)
//   2. clock     one position in the loop, shared by the drawing and the sound
//   3. branches  the event layer behind every page: each event grows its repeats
//   4. sound     runs the dendrite engine live in the page, or plays recordings made with it
//   5. controls  every sound control on the site, wherever it appears
//   6. stereo    the live display of the stereo field
//   7. field     the playable feed / space field, and the videos of the plug-in window
//   8. pages     swaps the page content on navigation, so the sound does not stop
//
// Without this script the site is a static, silent set of pages and still reads completely.

const TAKE = window.AFFERENT_TAKE;                 // from assets/take.js
const STAB = window.AFFERENT_STAB;                 // from assets/stab.js: the source dendrite plays
const EMBED = window.AFFERENT_EMBED ?? null;       // only set in the single-file preview build
const $ = (id) => document.getElementById(id);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const main = document.querySelector('main');

// words this script writes itself. the pages carry their own text; /tr/ pages set lang="tr".
const LANG = document.documentElement.lang === 'tr' ? 'tr' : 'en';
const TR = {
  'sound unavailable': 'ses kullanılamıyor', 'loading': 'yükleniyor', 'sound': 'ses', 'sound off': 'ses kapalı',
  'sound on': 'ses açık',
  'the engine of dendrite is running in this page. drag the light. hold the dark to throw.':
    'dendrite motoru bu sayfada çalışıyor. ışığı sürükle. throw için karanlığa basılı tut.',
  'nine recordings made with the engine of dendrite, one per point. drag the light.':
    'dendrite motoruyla yapılmış dokuz kayıt, her nokta için bir tane. ışığı sürükle.',
  'drag the light.': 'ışığı sürükle.',
  slower: 'yavaş', faster: 'hızlı', tempo: 'tempo',
  'windows installer': 'windows kurulum dosyası',
  '7.2 mb. puts dendrite.vst3 in the system vst3 folder.': '7,2 mb. dendrite.vst3\'ü sistemin vst3 klasörüne koyar.',
  'download for macos': 'macos için indir',
  '23.2 mb. vst3 and au, apple silicon and intel. not code-signed: allow it once.':
    '23,2 mb. vst3 ve au, apple silicon ve intel. kod imzalı değil: bir kez izin ver.',
  'download for linux': 'linux için indir', '7.0 mb. vst3.': '7,0 mb. vst3.',
  'dendrite runs on a computer. open afferent.page there, or pick a file below.':
    'dendrite bir bilgisayarda çalışır. afferent.page\'i orada aç ya da aşağıdan bir dosya seç.',
  'pick the file for your system.': 'sistemine uygun dosyayı seç.',
  afferent: 'afferent', works: 'işler', notes: 'notlar', type: 'yazı', 'in the lab': 'laboratuvarda', 'coming soon': 'yakında', specification: 'özellikler',
  dendrite: 'dendrite', window: 'pencere', repeats: 'tekrarlar', stereo: 'stereo', field: 'alan', fly: 'sinek',
  inside: 'içeride', download: 'indir',
};
const T = (text) => (LANG === 'tr' && TR[text]) || text;
document.documentElement.classList.add('js');

// The nine recorded points of the field: three feed settings by three space settings.
const FEED = [25, 50, 80];
const SPACE = [10, 40, 80];

const state = {
  sound: false,          // is sound wanted
  loading: false,
  failed: false,
  chain: 'dendrite',     // 'dry' or 'dendrite'
  mode: null,            // 'live' or 'recorded', decided when sound first starts (see 4. sound)
  fx: 50,                // place of the light on the field, in percent: across is space
  fy: 50,                //                                              up is feed
  fly: true,             // the itch: the fly may move the tape
};

// ---------------------------------------------------------------- 2. clock
//
// With sound on the position follows the audio clock, so drawing and sound stay together.
// With sound off it follows the page clock, so the drawing keeps running in silence.

const audio = {
  ctx: null,
  master: null,
  dryBus: null, dryOut: null, wetOut: null,
  engine: null,              // the AudioWorkletNode that runs dendrite, when live
  left: null, right: null,   // analysers for the stereo display
  takes: {},                 // name -> { buffer, gain, source, lead }
  hits: {},                  // name -> buffer
  playing: false,
  startedAt: 0,              // audio clock time when the loop started
  offset: 0,                 // loop position it started from
};

const loopSeconds = TAKE.seconds;
let pageEpoch = performance.now() / 1000;

function loopPosition(at) {
  const elapsed = audio.playing
    ? (at ?? audio.ctx.currentTime) - audio.startedAt + audio.offset
    : performance.now() / 1000 - pageEpoch;
  return ((elapsed % loopSeconds) + loopSeconds) % loopSeconds;
}

// Gives each event of the take once per loop. start(onEvent), stop().
// onEvent receives { x: 0..1, y: 0..1, energy: 0..1 }. A detector source would have the same shape.
function takeSource() {
  let last = loopPosition();
  let lastTick = performance.now();
  let timer = null;
  return {
    start(onEvent) {
      timer = setInterval(() => {
        const now = loopPosition();
        const tick = performance.now();
        const slept = tick - lastTick > 1500;            // the tab was in the background
        lastTick = tick;
        const wrapped = last - now > loopSeconds / 2;
        if (slept || (now < last && !wrapped)) { if (slept) last = now; return; }
        if (groove.running) { last = now; return; }      // live, the stabs draw themselves
        for (const ev of TAKE.events) {
          const due = wrapped ? ev.t > last || ev.t <= now : ev.t > last && ev.t <= now;
          if (due) onEvent(ev);
        }
        last = now;
      }, 25);
    },
    stop() { clearInterval(timer); },
  };
}

// ---------------------------------------------------------------- 3. branches
//
// One event, one point of light. With dendrite in the chain the point grows its repeats,
// placed by the plug-in's own rule: two read heads, a dotted eighth and a quarter of the
// tempo, both feeding back, so every repeat splits in two. Down the page is time.
// Sideways is the stereo field: the dotted head keeps the side, the quarter head inverts
// it, and each generation sits one step further from where the event was.
// The drawing follows that rule. It is not measured from the audio.

const canvas = $('marks');
const pen = canvas?.getContext('2d');
let nodes = [];

// the tempo: fixed for the recordings, set by the reader when the engine runs live
const BPM_MIN = 80, BPM_MAX = 160;
let bpm = TAKE.bpm;
const heads = () => [
  { delay: (60 / bpm) * 0.75, flips: false },    // dotted eighth
  { delay: 60 / bpm, flips: true },              // quarter
];
const GENERATIONS = 5;

// The layer covers the whole window, so its cost is its pixel count. It is drawn at no more
// than 1.25 device pixels per css pixel: the points are soft glows and look the same, and a
// phone with a 3x screen draws about six times fewer pixels than at full resolution.
function resizeCanvas() {
  const ratio = Math.min(window.devicePixelRatio || 1, 1.25);
  canvas.width = Math.round(window.innerWidth * ratio);
  canvas.height = Math.round(window.innerHeight * ratio);
  pen.setTransform(ratio, 0, 0, ratio, 0, 0);
  blank = false;
}

// One point of light, drawn once into a small image and stamped, instead of two filled
// circles per point per frame.
const SPRITE = 64;
const sprite = document.createElement('canvas');
sprite.width = sprite.height = SPRITE;
{
  const g = sprite.getContext('2d');
  const glow = g.createRadialGradient(SPRITE / 2, SPRITE / 2, 0, SPRITE / 2, SPRITE / 2, SPRITE / 2);
  glow.addColorStop(0, 'rgba(237, 237, 237, 1)');
  glow.addColorStop(0.2, 'rgba(237, 237, 237, 0.9)');
  glow.addColorStop(0.26, 'rgba(237, 237, 237, 0.2)');
  glow.addColorStop(1, 'rgba(237, 237, 237, 0)');
  g.fillStyle = glow;
  g.fillRect(0, 0, SPRITE, SPRITE);
}
let blank = false;            // nothing drawn since the last clear
let lastDraw = 0;

// x and y in pixels of the window
function grow(x, y, energy) {
  const born = performance.now();
  const scale = Math.min(1, window.innerWidth / 900) * 0.5 + 0.5;
  const stepX = 26 * scale;
  const stepY = 52 * scale;                              // pixels per second
  const radius = 2.2 + energy * 2.6;
  nodes.push({ x, y, r: radius, born, level: 1, life: reducedMotion ? 2500 : 5200 });
  if (state.chain !== 'dendrite' || reducedMotion) return;

  const branch = (px, py, parentBorn, delay, side, generation) => {
    if (generation > GENERATIONS) return;
    const node = {
      x: x + side * generation * stepX,
      y: y + delay * stepY,
      px, py, parentBorn,
      r: Math.max(0.9, radius * 0.78 ** generation),
      born: born + delay * 1000,
      level: 0.74 ** generation,
      life: 4200,
    };
    nodes.push(node);
    for (const head of heads()) {
      branch(node.x, node.y, node.born, delay + head.delay, head.flips ? -side : side, generation + 1);
    }
  };
  const side = x < window.innerWidth / 2 ? -1 : 1;
  for (const head of heads()) branch(x, y, born, head.delay, head.flips ? -side : side, 1);
}

window.AFFERENT_GROW = (x, y, energy) => grow(x, y, energy);

function onEvent(ev) {
  grow((0.08 + ev.x * 0.84) * window.innerWidth, (0.12 + ev.y * 0.6) * window.innerHeight, ev.energy);
}

function drawBranches(time) {
  requestAnimationFrame(drawBranches);
  // the points move slowly: 30 frames a second is enough and halves the cost
  if (time - lastDraw < 30) return;
  lastDraw = time;

  const now = performance.now();
  nodes = nodes.filter((n) => now - n.born < n.life);
  if (!nodes.length) {
    if (!blank) pen.clearRect(0, 0, window.innerWidth, window.innerHeight);
    blank = true;
    return;
  }
  blank = false;
  pen.clearRect(0, 0, window.innerWidth, window.innerHeight);

  // fainter once the reader has scrolled into the text
  const depth = Math.min(1, window.scrollY / (window.innerHeight * 0.7));
  const quiet = main.dataset.page === 'text' ? 0.35 : 1 - depth * 0.5;

  // strands first, all in one path per brightness step
  pen.lineWidth = 1;
  pen.strokeStyle = '#ededed';
  const steps = new Map();
  for (const n of nodes) {
    if (n.parentBorn === undefined || now <= n.parentBorn) continue;
    const age = (now - n.born) / n.life;
    const alpha = quiet * n.level * (age < 0 ? 1 : (1 - age) ** 1.6) * 0.45;
    const step = Math.round(alpha * 20);
    if (!step) continue;
    const reach = Math.min(1, (now - n.parentBorn) / (n.born - n.parentBorn));
    if (!steps.has(step)) steps.set(step, []);
    steps.get(step).push(n.px, n.py, n.px + (n.x - n.px) * reach, n.py + (n.y - n.py) * reach);
  }
  for (const [step, lines] of steps) {
    pen.globalAlpha = step / 20;
    pen.beginPath();
    for (let i = 0; i < lines.length; i += 4) {
      pen.moveTo(lines[i], lines[i + 1]);
      pen.lineTo(lines[i + 2], lines[i + 3]);
    }
    pen.stroke();
  }

  // then the points
  for (const n of nodes) {
    const age = (now - n.born) / n.life;
    if (age < 0) continue;                                        // the repeat is not due yet
    const flash = 1 + Math.max(0, 1 - (now - n.born) / 260) * 1.4; // a short swell as it lands
    const size = n.r * 8 * flash;
    pen.globalAlpha = quiet * n.level * (1 - age) ** 1.6;
    pen.drawImage(sprite, n.x - size / 2, n.y - size / 2, size, size);
  }
  pen.globalAlpha = 1;
}

// ---------------------------------------------------------------- 4. sound
//
// Two ways to hear dendrite, chosen when sound is first turned on:
//
//   live      the plug-in's engine itself runs in the page (assets/dendrite.wasm, compiled
//             from the plug-in's DSP source without changes, inside an AudioWorklet).
//             a dub chord stab is played in the page (assets/stab.js) and passes through
//             it. the field sets feed and space, the reader sets the tempo.
//   recorded  where the engine cannot run, or the device is too slow for it, the page plays
//             recordings made with the same engine: nine loops, one per point of the field.
//
// The recordings were made from the same stab, at 120 bpm (tools/render_stab.js).

const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));
const cellPlace = (index) => 18 + index * 32;                 // percent across the field
const cellIndex = (place) => clamp(Math.round((place - 18) / 32), 0, 2);

// the setting at a place on the field: a straight line through the three recorded settings
function valueAt(place, settings) {
  const t = (place - 18) / 32;
  const v = t <= 1 ? settings[0] + (settings[1] - settings[0]) * t : settings[1] + (settings[2] - settings[1]) * (t - 1);
  return clamp(v, 0, 100);
}
const feedNow = () => valueAt(state.fy, FEED);
const spaceNow = () => valueAt(state.fx, SPACE);
// the default point also has a take with the fly off, aligned with the one with it on
const activeTake = () => {
  if (state.chain === 'dry') return 'dry';
  const name = `f${cellIndex(state.fy)}s${cellIndex(state.fx)}`;
  return !state.fly && name === 'f1s1' ? 'f1s1-off' : name;
};

function base64ToArrayBuffer(text) {
  const binary = atob(text);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

// a file from assets/. the preview build carries some files inside itself.
async function loadBytes(path) {
  if (EMBED?.data[path]) return base64ToArrayBuffer(EMBED.data[path]);
  const response = await fetch(EMBED ? `assets/${path}` : `/assets/${path}`);
  if (!response.ok) throw new Error(`${response.status} for ${path}`);
  return response.arrayBuffer();
}

const loadBuffer = async (name) => audio.ctx.decodeAudioData(await loadBytes(`audio/${name}.mp3`));

function buildGraph() {
  const AudioCtx = window.AudioContext ?? window.webkitAudioContext;
  const ctx = (audio.ctx = new AudioCtx());
  audio.master = ctx.createGain();
  audio.master.gain.value = 0;
  audio.master.connect(ctx.destination);
  audio.dryBus = ctx.createGain();              // everything that has not been through dendrite

  const split = ctx.createChannelSplitter(2);
  audio.left = ctx.createAnalyser();
  audio.right = ctx.createAnalyser();
  audio.left.fftSize = audio.right.fftSize = 1024;
  audio.master.connect(split);
  split.connect(audio.left, 0);
  split.connect(audio.right, 1);
}

// Tries to start the engine in the page. Resolves to true when it runs fast enough.
async function startEngine() {
  const ctx = audio.ctx;
  try {
    if (!ctx.audioWorklet || !window.WebAssembly) return false;
    const wasm = await loadBytes('dendrite.wasm');
    // the worklet script is a file on the site. the preview carries it inside itself and
    // tries the ways a sandboxed page may be allowed to load it.
    const ways = EMBED
      ? [`data:text/javascript;base64,${btoa(EMBED.worklet)}`,
         URL.createObjectURL(new Blob([EMBED.worklet], { type: 'text/javascript' })),
         'assets/dendrite-worklet.js']
      : ['/assets/dendrite-worklet.js'];
    let loaded = false;
    for (const url of ways) {
      try { await ctx.audioWorklet.addModule(url); loaded = true; break; } catch (error) { console.warn(error); }
    }
    if (!loaded) return false;
    const node = new AudioWorkletNode(ctx, 'dendrite', {
      numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [2],
      channelCount: 2, channelCountMode: 'explicit',
      processorOptions: { wasm, bpm: TAKE.bpm },
    });
    const cost = await new Promise((resolve, reject) => {
      node.port.onmessage = (e) => resolve(e.data.cost);
      node.onprocessorerror = () => reject(new Error('the engine stopped'));
      setTimeout(() => reject(new Error('the engine did not start')), 20000);
    });
    console.info(`afferent: the engine needs ${Math.round(cost * 100)}% of real time on this device`);
    // the audio thread also mixes everything else; above about a third of real time a slow
    // or busy device starts to drop out, so it uses the recordings instead
    if (cost > 0.35) return false;

    audio.engine = node;
    audio.dryOut = ctx.createGain();
    audio.wetOut = ctx.createGain();
    audio.dryOut.gain.value = audio.wetOut.gain.value = 0;
    audio.dryBus.connect(audio.dryOut).connect(audio.master);
    audio.dryBus.connect(node).connect(audio.wetOut).connect(audio.master);
    return true;
  } catch (error) {
    console.warn('afferent: the engine could not start, using recordings.', error);
    return false;
  }
}

// The live part: stabs scheduled a little ahead on a beat clock. The engine is told the same
// clock (anchor), so its tempo grid, and the fly's, sit exactly on the stabs.
const groove = { running: false, seq: null, next: null, last: null, t0: 0, beat0: 0, timer: null };
const beatAt = (t) => groove.beat0 + ((t - groove.t0) * bpm) / 60;
const timeAtBeat = (b) => groove.t0 + ((b - groove.beat0) * 60) / bpm;

function anchorEngine() {
  audio.engine?.port.postMessage({ anchor: { time: groove.t0, beat: groove.beat0, bpm } });
}

function scheduleGroove() {
  const ctx = audio.ctx;
  for (;;) {
    const stab = groove.next;
    const when = timeAtBeat(stab.step / 4) + stab.timing;
    if (when > ctx.currentTime + 0.15) break;
    if (when >= ctx.currentTime) {
      STAB.play(ctx, audio.dryBus, when, stab);
      groove.last = stab;
      setTimeout(() => onEvent({ x: stab.x, y: stab.y, energy: (stab.velocity - 0.5) * 2 }),
        (when - ctx.currentTime) * 1000);
    }
    groove.next = groove.seq.next();
  }
}

function startGroove(when) {
  groove.seq ??= STAB.create(Date.now());
  groove.next ??= groove.seq.next();
  groove.t0 = when;
  groove.beat0 = Math.floor(groove.next.step / 16) * 4;    // the bar of the next stab starts now
  groove.running = true;
  anchorEngine();
  scheduleGroove();
  groove.timer = setInterval(scheduleGroove, 25);
}

function stopGroove() {
  clearInterval(groove.timer);
  groove.running = false;
}

function setTempo(value) {
  const next = clamp(Math.round(value), BPM_MIN, BPM_MAX);
  if (next === bpm) return;
  if (groove.running) {                       // the beat carries on from here at the new tempo
    const now = audio.ctx.currentTime;
    groove.beat0 = beatAt(now);
    groove.t0 = now;
  }
  bpm = next;
  anchorEngine();
  render();
}

function sendControls(more = {}) {
  audio.engine?.port.postMessage({ feed: feedNow() / 100, space: spaceNow() / 100, fly: state.fly, ...more });
}

function ramp(param, target, seconds) {
  const now = audio.ctx.currentTime;
  param.cancelScheduledValues(now);
  param.setValueAtTime(param.value, now);
  param.linearRampToValueAtTime(target, now + seconds);
}

// Loads one recording (once) and, if the loop is running, starts it in step with the others.
function ensureTake(name) {
  const known = audio.takes[name];
  if (known) return known.ready;
  const take = (audio.takes[name] = { buffer: null, gain: null, source: null, lead: 0, ready: null });
  take.ready = loadBuffer(name).then((buffer) => {
    take.buffer = buffer;
    // some browsers keep the encoder's 23 ms of silence at the start of an mp3
    take.lead = buffer.duration - loopSeconds > 0.04 ? 0.023 : 0;
    take.gain = audio.ctx.createGain();
    take.gain.gain.value = 0;
    take.gain.connect(name === 'dry' ? audio.dryBus : audio.master);
    if (audio.playing) startTake(take, audio.ctx.currentTime + 0.06);
  });
  take.ready.catch(() => { delete audio.takes[name]; });
  return take.ready;
}

function startTake(take, when) {
  const source = audio.ctx.createBufferSource();
  source.buffer = take.buffer;
  source.loop = true;
  source.loopStart = take.lead;
  source.loopEnd = Math.min(take.buffer.duration, take.lead + loopSeconds);
  source.connect(take.gain);
  source.start(when, take.lead + loopPosition(when));
  take.source = source;
}

function applyMix(seconds = 0.12) {
  const wet = state.chain === 'dendrite';
  if (state.mode === 'live') {
    ramp(audio.dryOut.gain, wet ? 0 : 1, seconds);
    ramp(audio.wetOut.gain, wet ? 1 : 0, seconds);
    return;
  }
  const active = activeTake();
  for (const [name, take] of Object.entries(audio.takes)) {
    if (take.gain) ramp(take.gain.gain, name === active ? 1 : 0, seconds);
  }
}

function startLoop() {
  const offset = loopPosition();                 // continue from where the drawing is
  const when = audio.ctx.currentTime + 0.06;
  audio.startedAt = when;
  audio.offset = offset;
  audio.playing = true;
  if (state.mode === 'live') startGroove(when);
  for (const take of Object.values(audio.takes)) if (take.buffer) startTake(take, when);
  ramp(audio.master.gain, 1, 0.5);
}

function stopLoop() {
  if (!audio.playing) return;
  pageEpoch = performance.now() / 1000 - loopPosition();       // the drawing carries on from here
  audio.playing = false;
  stopGroove();
  ramp(audio.master.gain, 0, 0.25);
  const old = Object.values(audio.takes).map((take) => take.source).filter(Boolean);
  for (const take of Object.values(audio.takes)) take.source = null;
  setTimeout(() => {
    old.forEach((source) => source.stop());
    if (!state.sound) audio.ctx.suspend();
  }, 350);
}

async function soundOn() {
  if (state.sound) return;
  state.sound = true;
  state.failed = false;
  document.body.classList.add('heard');
  if (!audio.ctx) buildGraph();                  // must happen inside the click or key press
  audio.ctx.resume();

  state.loading = true;
  render();
  try {
    if (!state.mode) {
      state.mode = (await startEngine()) ? 'live' : 'recorded';
      if (state.mode === 'recorded') {
        audio.dryBus.connect(audio.master);
        state.fx = cellPlace(cellIndex(state.fx));           // recordings exist only at the nine points
        state.fy = cellPlace(cellIndex(state.fy));
      }
    }
    if (state.mode === 'recorded') {
      await ensureTake('dry');
      await ensureTake(activeTake());
    } else sendControls();
  } catch (error) {
    console.error(error);
    state.sound = false;
    state.failed = true;
  }
  state.loading = false;

  if (state.sound && !audio.playing) {
    applyMix(0);
    startLoop();
  }
  render();
  say(state.failed ? T('sound unavailable') : state.sound ? `${T('sound on')}, ${state.chain}` : T('sound off'));
}

function soundOff() {
  if (!state.sound) return;
  state.sound = false;
  stopLoop();
  render();
  say(T('sound off'));
}

// Changes the chain or the place on the field.
async function choose(change) {
  Object.assign(state, change);
  if (state.mode === 'recorded') {
    state.fx = cellPlace(cellIndex(state.fx));
    state.fy = cellPlace(cellIndex(state.fy));
  }
  render();
  if (!state.sound) return soundOn();
  if (state.loading) return;
  if (state.mode === 'live') {
    sendControls();
    return applyMix();
  }
  const wanted = activeTake();
  try { await ensureTake(wanted); } catch (error) { console.error(error); return; }
  if (wanted === activeTake()) applyMix();
}

// A single stab, played where the reader taps. Five pitches; higher on the page is higher.
// Live, it is the stab itself, through the engine. Otherwise a recording of it through it.
const HIT_TRANSPOSE = [-7, -4, 0, 3, 7];
async function playHit(pitch) {
  const live = state.mode === 'live';
  if (live) {
    const stab = { ...(groove.last ?? groove.next), timing: 0 };
    STAB.play(audio.ctx, audio.dryBus, audio.ctx.currentTime + 0.005, stab, HIT_TRANSPOSE[pitch]);
    return;
  }
  const name = live ? `hit${pitch}-dry` : `hit${pitch}-${state.chain}`;
  try {
    audio.hits[name] ??= loadBuffer(name);
    const buffer = await audio.hits[name];
    if (!audio.playing) return;
    const source = audio.ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(live ? audio.dryBus : audio.master);
    source.start();
  } catch (error) {
    delete audio.hits[name];
    console.warn(error);
  }
}

// ---------------------------------------------------------------- 5. controls
//
//   data-action="sound"            toggles sound
//   data-action="dry"              takes dendrite out of the chain (and starts sound)
//   data-action="dendrite"         puts dendrite in the chain (and starts sound)
//   data-feed="1" data-space="2"   one of the nine points of the field
//   data-when="sound"              an element shown only while sound is on
//   data-when="silence"            ... only while it is off
//   data-label                     text inside a sound control; data-on / data-off set its words

function render() {
  const on = state.sound && !state.loading;
  for (const el of $$('[data-action="sound"]')) {
    el.setAttribute('aria-pressed', String(on));
    el.dataset.state = state.loading ? 'loading' : '';
    const label = el.querySelector('[data-label]');
    if (label) {
      label.textContent = state.failed ? T('sound unavailable')
        : state.loading ? T('loading')
        : on ? (label.dataset.on ?? T('sound')) : (label.dataset.off ?? T('sound'));
    }
  }
  for (const name of ['dry', 'dendrite']) {
    for (const el of $$(`[data-action="${name}"]`)) el.setAttribute('aria-pressed', String(on && state.chain === name));
  }
  for (const el of $$('[data-action="fly-on"]')) el.setAttribute('aria-pressed', String(state.fly));
  for (const el of $$('[data-action="fly-off"]')) el.setAttribute('aria-pressed', String(!state.fly));
  for (const el of $$('[data-when="sound"]')) el.hidden = !on;
  for (const el of $$('[data-when="silence"]')) el.hidden = on;
  for (const el of $$('[data-when="live"]')) el.hidden = !(on && state.mode === 'live');
  for (const el of $$('[data-bpm]')) el.textContent = String(bpm);

  for (const el of $$('.cell')) {
    const here = cellPlace(Number(el.dataset.feed)) === state.fy && cellPlace(Number(el.dataset.space)) === state.fx;
    el.setAttribute('aria-pressed', String(here && state.chain === 'dendrite'));
  }
  const light = $('light');
  if (light) {
    light.style.left = `${state.fx}%`;
    light.style.top = `${100 - state.fy}%`;
    light.style.opacity = state.chain === 'dendrite' ? 1 : 0.25;
  }
  const readout = $('readout');
  if (readout) readout.textContent = `feed ${Math.round(feedNow())}   space ${Math.round(spaceNow())}`;
  const note = $('engine-note');
  if (note) {
    note.textContent = T(state.mode === 'live' ? 'the engine of dendrite is running in this page. drag the light. hold the dark to throw.'
      : state.mode === 'recorded' ? 'nine recordings made with the engine of dendrite, one per point. drag the light.'
      : 'drag the light.');
  }
}

function say(text) {
  const live = $('live');
  if (live) live.textContent = text;
}

// ---------------------------------------------------------------- download sheet
//
// One sheet on every page. It puts the file for this visitor's system first.

function systemOf() {
  const ua = navigator.userAgent;
  const platform = (navigator.userAgentData?.platform || navigator.platform || '').toLowerCase();
  if (/iphone|ipad|ipod|android/i.test(ua)) return 'mobile';
  if (platform.includes('mac') || /mac os x/i.test(ua)) return 'mac';
  if (platform.includes('win') || /windows/i.test(ua)) return 'windows';
  if (platform.includes('linux') || /linux|x11/i.test(ua)) return 'linux';
  return 'other';
}

const SYSTEM_MAIN = {
  windows: ['windows installer', '7.2 mb. puts dendrite.vst3 in the system vst3 folder.'],
  mac: ['download for macos', '23.2 mb. vst3 and au, apple silicon and intel. not code-signed: allow it once.'],
  linux: ['download for linux', '7.0 mb. vst3.'],
};

function openSheet() {
  const sheet = $('sheet');
  if (!sheet?.showModal) { go(LANG === 'tr' ? '/tr/s-001/' : '/s-001/', 'get'); return; }
  const system = systemOf();
  const row = sheet.querySelector(`[data-os="${system}"]`);
  const first = $('sheet-main');
  const note = $('sheet-note');
  for (const li of sheet.querySelectorAll('[data-os]')) li.classList.toggle('here', li === row);
  if (row && SYSTEM_MAIN[system]) {
    first.hidden = false;
    first.href = row.querySelector('a').href;
    first.textContent = T(SYSTEM_MAIN[system][0]);
    note.textContent = T(SYSTEM_MAIN[system][1]);
  } else {
    first.hidden = true;
    note.textContent = T(system === 'mobile'
      ? 'dendrite runs on a computer. open afferent.page there, or pick a file below.'
      : 'pick the file for your system.');
  }
  sheet.showModal();
}

function closeSheet() { $('sheet')?.close(); }

$('sheet')?.addEventListener('click', (e) => {
  if (e.target === e.currentTarget) closeSheet();                 // a click on the backdrop
  else if (e.target.closest('a[href^="/"]')) closeSheet();        // a page link inside it
});

// ---------------------------------------------------------------- chapter rail (home)

const rail = document.querySelector('.rail');
const chapterWatch = new IntersectionObserver((entries) => {
  for (const entry of entries) {
    if (!entry.isIntersecting) continue;
    for (const a of rail.querySelectorAll('a')) a.setAttribute('aria-current', String(a.dataset.to === entry.target.dataset.chapter));
  }
}, { rootMargin: '-45% 0px -45% 0px' });

function buildRail() {
  if (!rail) return;
  chapterWatch.disconnect();
  const chapters = $$('main [data-chapter]');
  rail.hidden = chapters.length === 0;
  rail.innerHTML = '';
  for (const section of chapters) {
    const a = document.createElement('a');
    a.href = '#';
    a.dataset.to = section.dataset.chapter;
    a.innerHTML = `<span>${T(section.dataset.chapter)}</span>`;
    a.setAttribute('aria-label', T(section.dataset.chapter));
    a.addEventListener('click', (e) => { e.preventDefault(); e.stopImmediatePropagation(); section.scrollIntoView({ block: 'start' }); });
    rail.append(a);
    chapterWatch.observe(section);
  }
}

function act(action) {
  if (action === 'get') return openSheet();
  if (action === 'close') return closeSheet();
  if (action === 'sound') return state.sound ? soundOff() : soundOn();
  if (action === 'dry' || action === 'dendrite') return choose({ chain: action });
  if (action === 'fly-on' || action === 'fly-off') return choose({ fly: action === 'fly-on' });
  if (action === 'slower') return setTempo(bpm - 1);
  if (action === 'faster') return setTempo(bpm + 1);
}

// holding slower or faster keeps going, quicker the longer it is held
document.addEventListener('pointerdown', (e) => {
  const button = e.target.closest('[data-action="slower"], [data-action="faster"]');
  if (!button || e.button !== 0) return;
  let wait = 380, timer = null;
  const again = () => { act(button.dataset.action); wait = Math.max(40, wait * 0.8); timer = setTimeout(again, wait); };
  timer = setTimeout(again, wait);
  const release = () => { clearTimeout(timer); window.removeEventListener('pointerup', release); window.removeEventListener('pointercancel', release); };
  window.addEventListener('pointerup', release);
  window.addEventListener('pointercancel', release);
});

const isGround = (target) => !target.closest('a, button, video, .square, .top, .player, .sheet, .rail, .specimen, .grid');

document.addEventListener('click', (e) => {
  const control = e.target.closest('[data-action]');
  if (control) {
    if (control.tagName === 'A') {
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.button !== 0) return;   // let a new tab open the link
      e.preventDefault();
      e.stopImmediatePropagation();
    }
    return act(control.dataset.action);
  }
  const cell = e.target.closest('.cell');
  if (cell) {
    return choose({ chain: 'dendrite', fy: cellPlace(Number(cell.dataset.feed)), fx: cellPlace(Number(cell.dataset.space)) });
  }
  // a tap on empty ground: a point of light, and a stab if sound is on
  if (!isGround(e.target)) return;
  grow(e.clientX, e.clientY, 0.6);
  if (state.sound && audio.playing) playHit(clamp(Math.floor((1 - e.clientY / window.innerHeight) * 5), 0, 4));
});

// holding the ground is throw, as in the plug-in window: the input is sent into the loop harder
document.addEventListener('pointerdown', (e) => {
  if (state.mode !== 'live' || !audio.playing || !isGround(e.target)) return;
  sendControls({ throwHeld: 1 });
  const release = () => {
    sendControls({ throwHeld: 0 });
    window.removeEventListener('pointerup', release);
    window.removeEventListener('pointercancel', release);
  };
  window.addEventListener('pointerup', release);
  window.addEventListener('pointercancel', release);
});

// keys: s toggles sound, d switches between dry and dendrite
document.addEventListener('keydown', (e) => {
  if (e.metaKey || e.ctrlKey || e.altKey || e.repeat) return;
  if (e.target.closest('input, textarea, select, [contenteditable]')) return;
  if (e.key === 's') act('sound');
  if (e.key === 'd' && state.sound) act(state.chain === 'dry' ? 'dendrite' : 'dry');
});

// ---------------------------------------------------------------- 6. stereo
//
// Draws what is playing right now: each sample pair is one dot. Up is mid (left + right),
// sideways is side (left - right). A mono signal is a vertical line; width is stereo.

const samplesL = new Float32Array(1024);
const samplesR = new Float32Array(1024);

// drawn only while it is on screen; watched without reading the layout every frame
let scopeVisible = false;
let watchedScope = null;
const scopeWatch = new IntersectionObserver((entries) => {
  for (const entry of entries) scopeVisible = entry.isIntersecting;
});
function watchScope() {
  const scope = $('scope');
  if (scope === watchedScope) return;
  if (watchedScope) scopeWatch.unobserve(watchedScope);
  watchedScope = scope;
  scopeVisible = false;
  if (scope) scopeWatch.observe(scope);
}

function drawStereo() {
  const scope = $('scope');
  if (scope && audio.left && scopeVisible) {
    const size = scope.clientWidth;
    const ratio = Math.min(window.devicePixelRatio || 1, 1.5);
    if (scope.width !== Math.round(size * ratio)) scope.width = scope.height = Math.round(size * ratio);
    const ink = scope.getContext('2d');
    ink.setTransform(ratio, 0, 0, ratio, 0, 0);
    ink.globalAlpha = 1;
    ink.fillStyle = 'rgba(0, 0, 0, 0.16)';             // older dots fade instead of vanishing
    ink.fillRect(0, 0, size, size);
    if (audio.playing) {
      audio.left.getFloatTimeDomainData(samplesL);
      audio.right.getFloatTimeDomainData(samplesR);
      ink.fillStyle = '#ededed';
      ink.globalAlpha = 0.7;
      const gain = size * 2.4;
      for (let i = 0; i < samplesL.length; i += 2) {
        const mid = (samplesL[i] + samplesR[i]) / 2;
        const side = (samplesL[i] - samplesR[i]) / 2;
        ink.fillRect(size / 2 + side * gain * 2, size / 2 - mid * gain, 1.5, 1.5);
      }
    }
  }
  requestAnimationFrame(drawStereo);
}

// ---------------------------------------------------------------- 7. field and window
//
// The field: feed upward, space to the right. Live, the light can sit anywhere and sets the
// engine's two controls. With recordings it moves between the nine recorded points.

document.addEventListener('pointerdown', (e) => {
  const field = e.target.closest('.field');
  if (!field || e.button !== 0) return;
  const move = (ev) => {
    const box = field.getBoundingClientRect();
    choose({
      chain: 'dendrite',
      fx: clamp(((ev.clientX - box.left) / box.width) * 100, 6, 94),
      fy: clamp((1 - (ev.clientY - box.top) / box.height) * 100, 6, 94),
    });
  };
  const end = () => {
    field.classList.remove('dragging');
    window.removeEventListener('pointermove', move);
    window.removeEventListener('pointerup', end);
    window.removeEventListener('pointercancel', end);
  };
  field.classList.add('dragging');
  window.addEventListener('pointermove', move);
  window.addEventListener('pointerup', end);
  window.addEventListener('pointercancel', end);
  if (!e.target.closest('.cell')) move(e);             // a press between points also counts
});

// Videos of the plug-in window. They are silent and play only while on screen.
// The one marked data-follow="loop" was recorded over exactly one pass of the loop,
// so it is kept at the loop position: what the window shows is what is being heard.
const onScreen = new IntersectionObserver((entries) => {
  for (const { target, isIntersecting } of entries) {
    if (isIntersecting && !reducedMotion) target.play().catch(() => {});
    else target.pause();
  }
}, { threshold: 0.55 });          // more than half in view: only one video decodes at a time

function wireVideos() {
  for (const video of $$('video[data-video]')) {
    const file = `video/${video.dataset.video}.mp4`;
    if (!video.src) video.src = EMBED?.data[file] ? `data:video/mp4;base64,${EMBED.data[file]}` : `${EMBED ? '' : '/'}assets/${file}`;
    onScreen.observe(video);
  }
}

setInterval(() => {
  for (const video of $$('video[data-follow="loop"]')) {
    if (video.paused || video.readyState < 2) continue;
    // a small drift is taken up by playing a little faster or slower; only a large one seeks,
    // because seeking a video makes it stall while it decodes from the previous key frame
    const length = video.duration || loopSeconds;
    let drift = (loopPosition() % length) - video.currentTime;
    if (drift > length / 2) drift -= length;
    if (drift < -length / 2) drift += length;
    if (Math.abs(drift) > 1.5) {
      video.currentTime = loopPosition() % length;
      video.playbackRate = 1;
    } else {
      video.playbackRate = Math.abs(drift) < 0.05 ? 1 : 1 + Math.max(-0.08, Math.min(0.08, drift / 2));
    }
  }
}, 700);

// ---------------------------------------------------------------- 8. pages
//
// Every page is a real file and works alone. When this script runs, a click on an
// internal link fetches the next page and replaces only <main>, so the drawing and the
// sound continue. The address, the title and the back button behave as usual.

function pathOf(href) {
  const url = new URL(href, location.href);
  return { path: url.pathname.replace(/index\.html$/, ''), anchor: url.hash.slice(1) };
}

// in the preview build the pages are inside the file and the address is a plain #name
let currentPath = EMBED
  ? (location.hash.length > 1 ? `/${location.hash.slice(1)}/` : '/')
  : pathOf(location.href).path;

async function readPage(path) {
  if (EMBED) return EMBED.pages[path] ?? null;
  const response = await fetch(path);
  if (!response.ok) return null;
  const doc = new DOMParser().parseFromString(await response.text(), 'text/html');
  const next = doc.querySelector('main');
  return next ? { title: doc.title, kind: next.dataset.page, html: next.innerHTML } : null;
}

const seen = new IntersectionObserver((entries) => {
  for (const entry of entries) {
    if (entry.isIntersecting) { entry.target.classList.add('in'); seen.unobserve(entry.target); }
  }
}, { threshold: 0.15 });

function arrive() {
  for (const el of $$('.reveal')) seen.observe(el);
  watchScope();
  wireVideos();
  buildRail();
  for (const link of $$('.top a')) {
    if (pathOf(link.getAttribute('href')).path === currentPath) link.setAttribute('aria-current', 'page');
    else link.removeAttribute('aria-current');
  }
  render();
  window.AFFERENT_ALIVE?.arrive();
}

function show(page, path, anchor) {
  document.title = page.title;
  main.dataset.page = page.kind;
  main.innerHTML = page.html;
  currentPath = path;
  arrive();
  const target = anchor && $(anchor);
  if (target) target.scrollIntoView({ behavior: 'instant' });
  else window.scrollTo({ top: 0, behavior: 'instant' });
  main.focus({ preventScroll: true });
}

async function go(path, anchor, { push = true } = {}) {
  // the page is read while the old one leaves (assets/alive.js: each destination leaves differently)
  const [page, kind] = await Promise.all([
    readPage(path).catch((error) => { console.warn(error); return null; }),
    window.AFFERENT_ALIVE?.leave(currentPath, path),
  ]);
  if (!page) {
    if (!EMBED) location.href = path;            // let the browser load it the ordinary way
    else window.AFFERENT_ALIVE?.enter(null);
    return;
  }
  // a short cross-fade between pages where the browser can do it
  if (document.startViewTransition && !reducedMotion && !window.AFFERENT_ALIVE) document.startViewTransition(() => show(page, path, anchor));
  else show(page, path, anchor);
  window.AFFERENT_ALIVE?.enter(kind);
  if (!push) return;
  if (EMBED) location.hash = path.replace(/\//g, '');
  else history.pushState({}, '', path + (anchor ? `#${anchor}` : ''));
}

document.addEventListener('click', (e) => {
  const link = e.target.closest('a[href]');
  if (!link || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
  if (link.target || link.hasAttribute('download') || link.hasAttribute('hreflang')) return;
  const href = link.getAttribute('href');

  if (href.startsWith('#')) {                    // a section on this page
    const target = $(href.slice(1));
    if (!target) return;
    e.preventDefault();
    target.scrollIntoView();
    target.focus({ preventScroll: true });
    return;
  }
  if (!href.startsWith('/')) return;             // another site: leave it alone

  e.preventDefault();
  const { path, anchor } = pathOf(href);
  if (path === currentPath) {
    const target = anchor && $(anchor);
    if (target) target.scrollIntoView();
    else window.scrollTo(0, 0);
    return;
  }
  go(path, anchor);
});

if (EMBED) {
  window.addEventListener('hashchange', () => {
    const name = location.hash.slice(1);
    const path = name ? `/${name}/` : '/';
    if (path !== currentPath) go(path, '', { push: false });
  });
  go(currentPath in EMBED.pages ? currentPath : '/', '', { push: false });
} else {
  window.addEventListener('popstate', () => {
    const { path, anchor } = pathOf(location.href);
    if (path !== currentPath) go(path, anchor, { push: false });
  });
}

// ---------------------------------------------------------------- start

arrive();
if (canvas && pen) {
  window.addEventListener('resize', resizeCanvas);
  resizeCanvas();
  takeSource().start(onEvent);
  requestAnimationFrame(drawBranches);
  requestAnimationFrame(drawStereo);
}
