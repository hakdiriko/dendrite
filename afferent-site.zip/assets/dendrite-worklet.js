// Runs the dendrite engine (assets/dendrite.wasm, compiled from the plug-in's own DSP source,
// dendrite 3.0.0, with denormals flushed by hand: see sound/NOTES.md) on the audio thread.
// Sound comes in, passes through the engine, and goes out.
//
// Messages in:  { feed, space, throwHeld, itch, time, dry }   controls, as in the plug-in
//                                                             (itch: 0 off, 1..11, 10 = default)
//               { fly: true | false }                         the fly on (itch 10) or off (itch 0)
//               { seek: seconds }                             transport position
//               { reset: true }                               clears the engine (echo tail, fly state)
//               { anchor: { time, beat, bpm } }               a beat clock: at audio time `time`
//                                                             the song is at `beat`, at `bpm`
// Message out:  { ready: true, cost }   cost = share of real time one second of audio took

const ITCH_ON = 10;

class Dendrite extends AudioWorkletProcessor {
  constructor(options) {
    super();
    const stub = () => 0;
    const instance = new WebAssembly.Instance(new WebAssembly.Module(options.processorOptions.wasm), {
      env: { emscripten_notify_memory_growth() {} },
      wasi_snapshot_preview1: { fd_close: stub, fd_write: stub, fd_seek: stub },
    });
    this.engine = instance.exports;
    this.engine._initialize();
    this.engine.dn_prepare(sampleRate);
    this.controls = { feed: 0.5, space: 0.4, throwHeld: 0, itch: ITCH_ON, time: 0, dry: 1 };
    this.bpm = options.processorOptions.bpm;

    // measure this device: one second of stabs and silence through the engine, the fly awake.
    // (the old probe fed only clicks, which never reached the engine's slow paths)
    this.engine.dn_controls(0.5, 0.4, 0, ITCH_ON, 0, 1);
    const started = Date.now();
    const blocks = Math.ceil(sampleRate / 128);
    for (let block = 0; block < blocks; block++) {
      const left = this.view(this.engine.dn_left());
      if (block % 94 < 12) for (let i = 0; i < 128; i++) left[i] = 0.3 * Math.sin((block * 128 + i) * 0.0287);
      else left.fill(0);
      this.view(this.engine.dn_right()).set(left);
      this.engine.dn_process(128, this.bpm);
    }
    const cost = (Date.now() - started) / 1000;
    this.engine.dn_prepare(sampleRate);

    this.port.onmessage = (e) => {
      const m = e.data;
      if (m.seek !== undefined) return this.engine.dn_seek(m.seek);
      if (m.reset) {                                   // sound off: clear the echo, nothing keeps ringing
        this.engine.dn_prepare(sampleRate);
        const c = this.controls;
        return this.engine.dn_controls(c.feed, c.space, c.throwHeld, c.itch, c.time, c.dry);
      }
      if (m.anchor) { this.anchor = m.anchor; this.bpm = m.anchor.bpm; return; }
      const { fly, ...rest } = m;
      Object.assign(this.controls, rest);
      if (fly !== undefined) this.controls.itch = fly ? ITCH_ON : 0;
      const c = this.controls;
      this.engine.dn_controls(c.feed, c.space, c.throwHeld, c.itch, c.time, c.dry);
    };
    this.port.postMessage({ ready: true, cost });
  }

  view(pointer) {
    return new Float32Array(this.engine.memory.buffer, pointer, 128);
  }

  process(inputs, outputs) {
    const input = inputs[0];
    const output = outputs[0];
    const left = this.view(this.engine.dn_left());
    const right = this.view(this.engine.dn_right());
    if (input.length) {
      left.set(input[0]);
      right.set(input[1] ?? input[0]);
    } else {
      left.fill(0);
      right.fill(0);
    }
    if (this.anchor) {
      // the transport follows the page's beat clock, block by block
      const a = this.anchor;
      const beat = Math.max(0, a.beat + ((currentTime - a.time) * a.bpm) / 60);
      this.engine.dn_seek((beat * 60) / a.bpm);
    }
    this.engine.dn_process(128, this.bpm);
    output[0].set(this.view(this.engine.dn_left()));
    output[1]?.set(this.view(this.engine.dn_right()));
    return true;
  }
}

registerProcessor('dendrite', Dendrite);
