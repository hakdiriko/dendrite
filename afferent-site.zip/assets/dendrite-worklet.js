// Runs the dendrite engine (assets/dendrite.wasm, compiled from the plug-in's own DSP source)
// on the audio thread. Sound comes in, passes through the engine, and goes out.
//
// Messages in:  { feed, space, throwHeld, itch, time, dry }   controls, as in the plug-in
//               { seek: seconds }                             transport position
//               { anchor: { time, beat, bpm } }               a beat clock: at audio time `time`
//                                                             the song is at `beat`, at `bpm`
// Message out:  { ready: true, cost }   cost = share of real time one second of audio took

class Dendrite extends AudioWorkletProcessor {
  constructor(options) {
    super();
    const stub = () => 0;
    const instance = new WebAssembly.Instance(new WebAssembly.Module(options.processorOptions.wasm), {
      env: { emscripten_notify_memory_growth() {} },
      wasi_snapshot_preview1: { fd_close: stub, fd_write: stub, fd_seek: stub },
    });
    this.engine = instance.exports;
    this.engine._initialize();
    this.engine.dn_prepare(sampleRate);
    this.controls = { feed: 0.5, space: 0.4, throwHeld: 0, itch: 10, time: 0, dry: 1 };
    this.bpm = options.processorOptions.bpm;

    // measure this device: one second of clicks through the engine
    const started = Date.now();
    for (let block = 0; block < sampleRate / 128; block++) {
      const left = this.view(this.engine.dn_left());
      left.fill(0);
      if (block % 40 === 0) left[0] = 0.5;
      this.view(this.engine.dn_right()).set(left);
      this.engine.dn_process(128, this.bpm);
    }
    const cost = (Date.now() - started) / 1000;
    this.engine.dn_prepare(sampleRate);

    this.port.onmessage = (e) => {
      if (e.data.seek !== undefined) return this.engine.dn_seek(e.data.seek);
      if (e.data.anchor) { this.anchor = e.data.anchor; this.bpm = e.data.anchor.bpm; return; }
      Object.assign(this.controls, e.data);
      const c = this.controls;
      this.engine.dn_controls(c.feed, c.space, c.throwHeld, c.itch, c.time, c.dry);
    };
    this.port.postMessage({ ready: true, cost });
  }

  view(pointer) {
    return new Float32Array(this.engine.memory.buffer, pointer, 128);
  }

  process(inputs, outputs) {
    const input = inputs[0];
    const output = outputs[0];
    const left = this.view(this.engine.dn_left());
    const right = this.view(this.engine.dn_right());
    if (input.length) {
      left.set(input[0]);
      right.set(input[1] ?? input[0]);
    } else {
      left.fill(0);
      right.fill(0);
    }
    if (this.anchor) {
      // the transport follows the page's beat clock, block by block
      const a = this.anchor;
      const beat = Math.max(0, a.beat + ((currentTime - a.time) * a.bpm) / 60);
      this.engine.dn_seek((beat * 60) / a.bpm);
    }
    this.engine.dn_process(128, this.bpm);
    output[0].set(this.view(this.engine.dn_left()));
    output[1]?.set(this.view(this.engine.dn_right()));
    return true;
  }
}

registerProcessor('dendrite', Dendrite);
