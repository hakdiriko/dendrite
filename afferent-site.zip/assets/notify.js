// afferent.page: the release note sign-up.
// one field, posted to /api/notify (the worker in _worker.js keeps it in cloudflare d1 until the
// one email is sent). without this script the form still posts and the worker answers with a page.
(() => {
  document.addEventListener('submit', async (e) => {
    const form = e.target.closest && e.target.closest('form[data-notify]');
    if (!form) return;
    e.preventDefault();
    const status = form.parentElement.querySelector('[data-notify-status]');
    const button = form.querySelector('button[type="submit"]');
    const say = (text) => { if (status) status.textContent = text; };
    const data = new FormData(form);
    button.disabled = true;
    try {
      const response = await fetch(form.action, {
        method: 'POST',
        headers: { accept: 'application/json', 'content-type': 'application/json' },
        body: JSON.stringify({ email: data.get('email'), website: data.get('website') }),
      });
      const answer = await response.json().catch(() => ({}));
      if (response.ok) {
        form.hidden = true;
        say(answer.message || "you're on it. one email, then we forget you.");
      } else {
        say(answer.message || 'that did not work. write to hello@afferent.page instead.');
        button.disabled = false;
      }
    } catch {
      say('no connection. try again, or write to hello@afferent.page.');
      button.disabled = false;
    }
  });
})();
