// afferent. the source the site plays into dendrite: a small dub-techno part, v4 (2026-11-23).
//
//   stab   "felt": two soft saws per note through a dark 24 dB low-pass (q under 1), 8 ms attack,
//          a quiet sine sub. no folder, no fm, no resonance (v2 was harsh because of all three).
//   kick   a dub kick: one sine, pitch falling 110 -> 46 Hz, a soft 3 ms attack, no distortion.
//          it does not go through dendrite and sits under the stabs in level.
//
// The part (an 8-bar phrase, repeated with small changes):
//   harmony   two bars each: dm9 -> bbmaj9 -> gm11 -> a7sus4, voice-led (one or two notes move
//             at a time, never closer than a whole tone), then back to dm9. no more random climbing.
//   rhythm    stabs on "1 &" and "3 &" (the eighth after the kick). bar 4 adds a soft pickup on
//             "4 &", bar 6 a ghost on "2 &". bar 8 plays one long open stab (the throw) and
//             leaves the rest of the bar to the echo, so the fly's moves can be heard.
//   kick      bars 1 to 4: stabs alone. bars 5 to 8: the kick on beats 1 and 3. from bar 9 on,
//             four on the floor, for as long as the part plays (it has no end). each kick ducks the stabs by about 4 dB
//             (AFFERENT_STAB.duck on the stab bus after dendrite, like a sidechain compressor).
//   motion    the filter opens and closes over 16 bars; cutoff, decay, detune, velocity and
//             timing still drift a little per hit, so no two stabs are the same.
//
//   const part = AFFERENT_STAB.create(seed)
//   part.next() -> { kind: 'stab' | 'kick', step (sixteenths from the start), ... }
//   AFFERENT_STAB.play(ctx, out, when, stab, inversion = 0)   one stab (inversion -2..2: in key)
//   AFFERENT_STAB.kick(ctx, out, when, hit)                   one kick
//   AFFERENT_STAB.duck(gainParam, when)                       the kick's 4 dB duck on the stab bus
//
// The same code renders the recordings (tools/render_stab.js, in an OfflineAudioContext).

(() => {
  // bars 1-4 alone, 5-8 the kick on 1 and 3, then four on the floor with no end
  const KICK_STEPS = (bar) => (bar < 4 ? [] : bar < 8 ? [0, 8] : [0, 4, 8, 12]);
  const DUCK_DB = 4;
  const KICK_LEVEL = 0.25;         // about 3 dB under the stabs after dendrite (rms): present, never on top

  // [step, accent, flags]
  const PATTERN = [
    [[2, 1], [10, 0.86]],
    [[2, 1], [10, 0.86]],
    [[2, 1], [10, 0.86]],
    [[2, 1], [10, 0.86], [14, 0.6]],
    [[2, 1], [10, 0.86]],
    [[2, 1], [6, 0.55], [10, 0.86]],
    [[2, 1], [10, 0.86]],
    [[2, 1, 'throw']],
  ];
  // the second time through, the small notes move
  const PATTERN_B = PATTERN.map((bar, i) =>
    i === 3 ? [[2, 1], [10, 0.86]] : i === 5 ? [[2, 1], [10, 0.86], [13, 0.55]] : i === 6 ? [[2, 1], [10, 0.86], [14, 0.6]] : bar);

  const CHORDS = [
    { name: 'dm9',    notes: [53, 57, 60, 64], sub: 38 },   // f a c e   / d
    { name: 'bbmaj9', notes: [53, 57, 60, 62], sub: 46 },   // f a c d   / bb
    { name: 'gm11',   notes: [53, 58, 60, 62], sub: 43 },   // f bb c d  / g
    { name: 'a7sus4', notes: [52, 55, 57, 62], sub: 45 },   // e g a d   / a
  ];

  const DRIFT = {
    cutoff:   { lo: 1300, hi: 2400, centre: 0.4, push: 0.03, log: true },
    decay:    { lo: 0.22, hi: 0.36, centre: 0.45, push: 0.03 },
    detune:   { lo: 2, hi: 7, centre: 0.4, push: 0.03 },
    velocity: { lo: 0.8, hi: 0.9, centre: 0.5, push: 0.04 },
    timing:   { lo: -0.003, hi: 0.003, centre: 0.5, push: 0.05 },
    x:        { lo: 0, hi: 1, centre: 0.5, push: 0.05 },
    y:        { lo: 0, hi: 1, centre: 0.45, push: 0.05 },
  };
  const FRICTION = 0.86, PULL = 0.012;

  function random(seed) {
    let s = (seed >>> 0) || 0x9e3779b9;
    return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
  }

  function create(seed = Date.now()) {
    const rnd = random(seed);
    const gauss = () => Math.sqrt(-2 * Math.log(rnd() + 1e-12)) * Math.cos(2 * Math.PI * rnd());
    const value = {}, speed = {};
    for (const [n, d] of Object.entries(DRIFT)) { value[n] = d.centre; speed[n] = 0; }
    let bar = 0, queue = [];
    const read = (n) => { const d = DRIFT[n], v = value[n]; return d.log ? d.lo * (d.hi / d.lo) ** v : d.lo + (d.hi - d.lo) * v; };
    const drift = () => {
      for (const [n, d] of Object.entries(DRIFT)) {
        speed[n] = speed[n] * FRICTION + d.push * gauss() + PULL * (d.centre - value[n]);
        let v = value[n] + speed[n];
        if (v < 0) { v = -v; speed[n] = Math.abs(speed[n]); }
        if (v > 1) { v = 2 - v; speed[n] = -Math.abs(speed[n]); }
        value[n] = Math.min(1, Math.max(0, v));
      }
    };

    function fillBar() {
      const inPhrase = bar % 8, phrase = Math.floor(bar / 8);
      const chord = CHORDS[Math.floor(inPhrase / 2)];
      const arc = 0.82 + 0.36 * (0.5 - 0.5 * Math.cos((2 * Math.PI * (bar % 16)) / 16));   // 16-bar filter swell
      const events = [];
      for (const s of KICK_STEPS(bar)) events.push({ kind: 'kick', step: bar * 16 + s, velocity: s === 0 ? 1 : 0.86 + 0.06 * rnd(), timing: 0, bar });
      for (const [s, accent, flag] of (phrase % 2 ? PATTERN_B : PATTERN)[inPhrase]) {
        drift();
        const stab = { kind: 'stab', step: bar * 16 + s, bar, chord: chord.name, notes: chord.notes, root: chord.sub + 12 };
        for (const n of Object.keys(DRIFT)) stab[n] = read(n);
        stab.cutoff *= arc;
        stab.velocity *= accent;
        if (flag === 'throw') { stab.decay *= 1.9; stab.cutoff *= 1.25; stab.velocity = Math.max(stab.velocity, 0.86); stab.throw = true; }
        events.push(stab);
      }
      events.sort((a, b) => a.step - b.step || (a.kind === 'kick' ? -1 : 1));
      queue = events;
      bar++;
    }

    return { next() { if (!queue.length) fillBar(); return queue.shift(); } };
  }

  const hz = (m) => 440 * 2 ** ((m - 69) / 12);

  // inversions stay in key: each step up moves the lowest note an octave up (down: the highest down)
  function invert(notes, k) {
    let n = [...notes].sort((a, b) => a - b);
    for (; k > 0; k--) n = [...n.slice(1), n[0] + 12];
    for (; k < 0; k++) n = [n[n.length - 1] - 12, ...n.slice(0, -1)];
    return n;
  }

  function play(ctx, out, when, stab, inversion = 0) {
    const notes = invert(stab.notes, inversion);
    const end = when + stab.decay * 3 + 0.1;
    const attack = 0.008;
    const hp = ctx.createBiquadFilter(), lp1 = ctx.createBiquadFilter(), lp2 = ctx.createBiquadFilter(), amp = ctx.createGain();
    hp.type = 'highpass'; hp.frequency.value = 110; hp.Q.value = 0.5;
    lp1.type = lp2.type = 'lowpass'; lp1.Q.value = 0.6; lp2.Q.value = 0.9;
    const open = Math.min(3000, stab.cutoff), shut = Math.max(550, stab.cutoff * 0.35);
    for (const lp of [lp1, lp2]) {
      lp.frequency.setValueAtTime(open, when);
      lp.frequency.setTargetAtTime(shut, when + attack, stab.decay * 0.4);
    }
    amp.gain.setValueAtTime(0, when);
    amp.gain.linearRampToValueAtTime(0.88 * stab.velocity, when + attack);
    amp.gain.setTargetAtTime(0, when + attack, stab.decay / 3.2);
    hp.connect(lp1).connect(lp2).connect(amp).connect(out);
    const each = 1 / notes.length;
    for (const note of notes) for (const side of [-1, 1]) {
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.type = 'sawtooth'; o.frequency.value = hz(note); o.detune.value = side * stab.detune;
      g.gain.value = each * 0.5;
      o.connect(g).connect(hp); o.start(when); o.stop(end);
    }
    // the sub: a sine on the chord's root, quiet, outside the filters
    const s = ctx.createOscillator(), sg = ctx.createGain();
    s.frequency.value = hz(stab.root - 12);
    sg.gain.setValueAtTime(0, when);
    sg.gain.linearRampToValueAtTime(0.08 * stab.velocity, when + 0.012);
    sg.gain.setTargetAtTime(0, when + 0.012, stab.decay / 2.6);
    s.connect(sg).connect(out); s.start(when); s.stop(end);
    return end;
  }

  function kick(ctx, out, when, hit = {}) {
    const v = hit.velocity ?? 1, end = when + 0.9;
    const o = ctx.createOscillator(), g = ctx.createGain(), lp = ctx.createBiquadFilter();
    o.frequency.setValueAtTime(110, when);
    o.frequency.exponentialRampToValueAtTime(46, when + 0.08);
    lp.type = 'lowpass'; lp.frequency.value = 220; lp.Q.value = 0.5;   // takes the edge off the attack
    g.gain.setValueAtTime(0, when);
    g.gain.linearRampToValueAtTime(KICK_LEVEL * v, when + 0.003);
    g.gain.setTargetAtTime(0, when + 0.02, 0.15);
    o.connect(lp).connect(g).connect(out);
    o.start(when); o.stop(end);
    return end;
  }

  // sidechain: down about 4 dB in 4 ms, back over about 250 ms
  function duck(param, when) {
    const low = 10 ** (-DUCK_DB / 20);
    param.cancelScheduledValues(when);
    param.setTargetAtTime(low, when, 0.004);
    param.setTargetAtTime(1, when + 0.04, 0.08);
  }

  window.AFFERENT_STAB = { create, play, kick, duck, invert, random, CHORDS };
})();
