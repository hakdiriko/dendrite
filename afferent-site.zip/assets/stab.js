// afferent. the source the site plays into dendrite: a dry dub chord stab whose sound keeps
// warping, slowly.
//
// One voice per chord note. Each voice is a sine carrier frequency-modulated by a second
// sine, blended with a saw. All voices go through a wavefolder, then a low-pass with a short
// pluck on its cutoff. A sine sub an octave under the root sits outside the folder.
// No reverb, no delay: everything you hear repeat is dendrite.
//
// Nothing is dice. Every control drifts: each stab nudges a velocity, the velocity nudges
// the value, and both are pulled back toward a centre, so values move in slow arcs rather
// than steps. The drifting controls:
//   timbre    fm amount, fm ratio (harmonic to inharmonic and back), fold, saw/sine shape,
//             sub level, detune, cutoff, resonance, decay
//   harmony   the voicing: now and then one note of the chord moves a step, one at a time
//   feel      velocity and timing, only a little
//
//   const groove = AFFERENT_STAB.create(seed)   a sequence: groove.next() gives the next stab
//   AFFERENT_STAB.play(ctx, out, when, stab, transpose)   schedules one stab on a Web Audio graph
//
// The same code renders the recordings (tools/render_stab.js, in an OfflineAudioContext).

(() => {
  // a steady part: one stab on the off-beat of beats one and three, every bar.
  // only the last bar of eight leaves one out, so the echo has a whole bar to itself.
  const STEPS = [2, 10];
  const ROOT = 50;                                  // d. the key does not matter.
  const ALLOWED = [2, 3, 5, 7, 9, 10, 12, 14, 15, 17, 19];   // intervals above the root a voice may sit on
  const START = [3, 7, 10, 14];                     // d minor 9 without the root, the root is the sub

  // each control: low, high, centre (0..1 of the range), how much one stab pushes it, log scale
  const DRIFT = {
    fm:       { lo: 0, hi: 3.2, centre: 0.3, push: 0.035 },             // modulation index
    ratio:    { lo: 0.5, hi: 3.5, centre: 0.18, push: 0.025 },          // modulator / carrier
    fold:     { lo: 0, hi: 1, centre: 0.3, push: 0.035 },
    shape:    { lo: 0, hi: 1, centre: 0.45, push: 0.035 },              // 0 sine-fm, 1 saw
    sub:      { lo: 0, hi: 0.7, centre: 0.4, push: 0.03 },
    detune:   { lo: 1, hi: 16, centre: 0.35, push: 0.03 },              // cents, each side
    cutoff:   { lo: 500, hi: 3600, centre: 0.45, push: 0.03, log: true },
    q:        { lo: 0.7, hi: 5, centre: 0.3, push: 0.025 },
    decay:    { lo: 0.16, hi: 0.5, centre: 0.45, push: 0.03 },          // seconds
    velocity: { lo: 0.68, hi: 0.9, centre: 0.5, push: 0.04 },
    timing:   { lo: -0.004, hi: 0.004, centre: 0.5, push: 0.05 },       // seconds off the grid
    x:        { lo: 0, hi: 1, centre: 0.5, push: 0.05 },                // where it is drawn
    y:        { lo: 0, hi: 1, centre: 0.45, push: 0.05 },
  };
  const FRICTION = 0.86;   // how much of its velocity a control keeps from one stab to the next
  const PULL = 0.012;      // how strongly it is drawn back toward its centre

  function random(seed) {
    let s = (seed >>> 0) || 0x9e3779b9;
    return () => {
      s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0;
      return s / 4294967296;
    };
  }

  function create(seed = Date.now()) {
    const rnd = random(seed);
    const gauss = () => Math.sqrt(-2 * Math.log(rnd() + 1e-12)) * Math.cos(2 * Math.PI * rnd());
    const value = {}, speed = {};
    for (const [name, d] of Object.entries(DRIFT)) { value[name] = d.centre; speed[name] = 0; }
    let voicing = [...START], bar = 0, queue = [];

    // the harmony: at the start of every other bar, maybe one note of the chord moves a step
    function moveVoice() {
      if (rnd() < 0.45) return;
      const i = Math.floor(rnd() * voicing.length);
      const at = ALLOWED.indexOf(voicing[i]);
      const to = ALLOWED[at + (rnd() < 0.5 ? -1 : 1)];
      if (to === undefined || voicing.includes(to)) return;
      voicing[i] = to;
      voicing.sort((a, b) => a - b);
    }

    function fillBar() {
      if (bar % 2 === 0 && bar > 0) moveVoice();
      const steps = bar % 8 === 7 ? [STEPS[0]] : STEPS;
      queue = steps.map((s) => bar * 16 + s);
      bar++;
    }

    const read = (name) => {
      const d = DRIFT[name], v = value[name];
      return d.log ? d.lo * (d.hi / d.lo) ** v : d.lo + (d.hi - d.lo) * v;
    };

    return {
      // the next stab: { step (sixteenths from the start), notes (midi), and every drifting control }
      next() {
        if (!queue.length) fillBar();
        for (const [name, d] of Object.entries(DRIFT)) {
          speed[name] = speed[name] * FRICTION + d.push * gauss() + PULL * (d.centre - value[name]);
          let v = value[name] + speed[name];
          if (v < 0) { v = -v; speed[name] = Math.abs(speed[name]); }
          if (v > 1) { v = 2 - v; speed[name] = -Math.abs(speed[name]); }
          value[name] = Math.min(1, Math.max(0, v));
        }
        const stab = { step: queue.shift(), notes: voicing.map((i) => ROOT + i), root: ROOT };
        for (const name of Object.keys(DRIFT)) stab[name] = read(name);
        return stab;
      },
    };
  }

  const hz = (midi) => 440 * 2 ** ((midi - 69) / 12);

  // the wavefolder's curve, made once per context: three folds across the input range,
  // so a small drive is a soft saturation and a large one folds the wave over itself
  const curves = new WeakMap();
  function foldCurve(ctx) {
    if (!curves.has(ctx)) {
      const n = 2048, c = new Float32Array(n);
      for (let i = 0; i < n; i++) { const x = (i / (n - 1)) * 2 - 1; c[i] = Math.sin(x * Math.PI * 1.5); }
      curves.set(ctx, c);
    }
    return curves.get(ctx);
  }

  // one stab on a Web Audio graph, mono, into out
  function play(ctx, out, when, stab, transpose = 0) {
    const end = when + stab.decay * 2.6 + 0.08;
    const drive = ctx.createGain();
    const folder = ctx.createWaveShaper();
    const filter = ctx.createBiquadFilter();
    const low = ctx.createBiquadFilter();
    const amp = ctx.createGain();
    folder.curve = foldCurve(ctx);
    folder.oversample = '2x';
    drive.gain.value = 0.22 + stab.fold * 0.78;
    filter.type = 'lowpass';
    filter.Q.value = stab.q;
    filter.frequency.setValueAtTime(Math.min(16000, stab.cutoff * 2), when);
    filter.frequency.setTargetAtTime(stab.cutoff * 0.6, when + 0.004, stab.decay * 0.45);
    low.type = 'highpass';
    low.frequency.value = 35;
    const peak = 0.3 * stab.velocity / (0.6 + stab.fold * 0.4);
    amp.gain.setValueAtTime(0, when);
    amp.gain.linearRampToValueAtTime(peak, when + 0.006);
    amp.gain.setTargetAtTime(0, when + 0.006, stab.decay / 3);
    drive.connect(folder).connect(filter).connect(low).connect(amp).connect(out);

    const start = (osc) => { osc.start(when); osc.stop(end); return osc; };
    const each = 1 / stab.notes.length;
    for (const note of stab.notes) {
      const f = hz(note + transpose);
      // sine carrier, frequency-modulated; the modulation dies away faster than the note
      const carrier = start(ctx.createOscillator());
      const modulator = start(ctx.createOscillator());
      const depth = ctx.createGain();
      carrier.frequency.value = f;
      carrier.detune.value = -stab.detune;
      modulator.frequency.value = f * stab.ratio;
      depth.gain.setValueAtTime(f * stab.ratio * stab.fm, when);
      depth.gain.setTargetAtTime(f * stab.ratio * stab.fm * 0.25, when, stab.decay * 0.5);
      modulator.connect(depth).connect(carrier.frequency);
      // saw beside it, detuned the other way
      const saw = start(ctx.createOscillator());
      saw.type = 'sawtooth';
      saw.frequency.value = f;
      saw.detune.value = stab.detune;
      const sine = ctx.createGain(), edge = ctx.createGain();
      sine.gain.value = each * 0.8 * (1 - stab.shape);
      edge.gain.value = each * 0.55 * stab.shape;
      carrier.connect(sine).connect(drive);
      saw.connect(edge).connect(drive);
    }
    // the sub: a sine an octave under the root, after the folder, so it stays round
    const sub = start(ctx.createOscillator());
    sub.frequency.value = hz(stab.root + transpose - 12);
    const subLevel = ctx.createGain();
    subLevel.gain.value = stab.sub * 0.9;
    sub.connect(subLevel).connect(filter);
    return end;
  }

  window.AFFERENT_STAB = { create, play };
})();
