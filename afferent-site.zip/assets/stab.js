// afferent. the source the site plays into dendrite: a dry dub chord stab.
//
// One chord, short and percussive: saw oscillators in pairs, slightly detuned, through a
// resonant low-pass whose cutoff falls with each hit. No reverb, no delay: everything you
// hear repeat is dendrite.
//
// Nothing is dice. Each stab moves its cutoff, resonance, decay, detune, velocity and timing
// a little from the one before (a random walk pulled back toward its centre), so the part
// drifts like a hand on the knobs.
//
//   const groove = AFFERENT_STAB.create(seed)   a sequence: groove.next() gives the next stab
//   AFFERENT_STAB.play(ctx, out, when, stab, transpose)   schedules one stab on a Web Audio graph
//
// The same code renders the recordings (tools/render_stab.js, in an OfflineAudioContext).

(() => {
  // a 4-bar part on sixteenth notes. the gaps are where the echo is heard.
  const PATTERN = [[2, 10], [2, 7, 10], [2, 10], [2, 10, 13]];
  const CHORD = [50, 53, 57, 60, 64];   // the chord does not matter. this one is d minor 9.

  // each control: low, high, centre (0..1 of the range), how far a step walks, log scale
  const WALK = {
    cutoff:   { lo: 420, hi: 2800, centre: 0.42, step: 0.07, log: true },   // hz
    q:        { lo: 1.2, hi: 9, centre: 0.4, step: 0.06 },
    decay:    { lo: 0.07, hi: 0.38, centre: 0.38, step: 0.06 },              // seconds
    detune:   { lo: 2, hi: 22, centre: 0.35, step: 0.06 },                   // cents, each side
    velocity: { lo: 0.5, hi: 1, centre: 0.65, step: 0.07 },
    timing:   { lo: -0.014, hi: 0.014, centre: 0.5, step: 0.08 },           // seconds off the grid
    x:        { lo: 0, hi: 1, centre: 0.5, step: 0.1 },                      // where it is drawn
    y:        { lo: 0, hi: 1, centre: 0.45, step: 0.1 },
  };
  const PULL = 0.08;   // how strongly each walk is drawn back toward its centre

  function random(seed) {
    let s = (seed >>> 0) || 0x9e3779b9;
    return () => {
      s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0;
      return s / 4294967296;
    };
  }

  function create(seed = Date.now()) {
    const rnd = random(seed);
    const gauss = () => Math.sqrt(-2 * Math.log(rnd() + 1e-12)) * Math.cos(2 * Math.PI * rnd());
    const walk = {};
    for (const [name, w] of Object.entries(WALK)) walk[name] = w.centre;
    let bar = 0, queue = [];

    const value = (name) => {
      const w = WALK[name], v = walk[name];
      return w.log ? w.lo * (w.hi / w.lo) ** v : w.lo + (w.hi - w.lo) * v;
    };

    function fillBar() {
      const steps = [...PATTERN[bar % PATTERN.length]];
      // now and then a hit is left out or one is added, never the first of the bar
      if (steps.length > 2 && rnd() < 0.15) steps.splice(1 + Math.floor(rnd() * (steps.length - 1)), 1);
      if (rnd() < 0.1 && !steps.includes(14)) steps.push(14);
      queue = steps.map((s) => bar * 16 + s);
      bar++;
    }

    return {
      // the next stab: { step (sixteenths from the start), timing (s), cutoff, q, decay, detune, velocity, x, y }
      next() {
        if (!queue.length) fillBar();
        for (const [name, w] of Object.entries(WALK)) {
          let v = walk[name] + PULL * (w.centre - walk[name]) + w.step * gauss();
          if (v < 0) v = -v; if (v > 1) v = 2 - v;          // bounce off the ends
          walk[name] = Math.min(1, Math.max(0, v));
        }
        const stab = { step: queue.shift() };
        for (const name of Object.keys(WALK)) stab[name] = value(name);
        return stab;
      },
    };
  }

  const hz = (midi) => 440 * 2 ** ((midi - 69) / 12);

  // one stab on a Web Audio graph, mono, into out
  function play(ctx, out, when, stab, transpose = 0) {
    const amp = ctx.createGain();
    const filter = ctx.createBiquadFilter();
    const low = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.Q.value = stab.q;
    low.type = 'highpass';                    // keeps the low end clear, as dub stabs are
    low.frequency.value = 140;
    filter.frequency.setValueAtTime(Math.min(16000, stab.cutoff * 2.4), when);
    filter.frequency.setTargetAtTime(stab.cutoff * 0.55, when + 0.002, stab.decay * 0.35);
    const peak = 0.11 * stab.velocity;
    amp.gain.setValueAtTime(0, when);
    amp.gain.linearRampToValueAtTime(peak, when + 0.003);
    amp.gain.setTargetAtTime(0, when + 0.003, stab.decay / 3.2);
    filter.connect(low).connect(amp).connect(out);

    const end = when + stab.decay * 2.2 + 0.05;
    for (const note of CHORD) {
      for (const side of [-1, 1]) {
        const osc = ctx.createOscillator();
        osc.type = 'sawtooth';
        osc.frequency.value = hz(note + transpose);
        osc.detune.value = side * stab.detune;
        osc.connect(filter);
        osc.start(when);
        osc.stop(end);
      }
    }
    return end;
  }

  window.AFFERENT_STAB = { create, play };
})();
