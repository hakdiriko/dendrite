// afferent. the three slides at the top of the home page: itch, space, keep.
//
// Everything here moves on springs, not on fixed curves: each moving value has a mass, a
// stiffness and a damping, is pulled toward a target, and keeps its velocity when the target
// changes. A slide change, a drag that is let go, and the three motions all work this way.
//
// Each slide shows one thing dendrite does, with one motion:
//   itch   a read head sits on the tape. the fly fires, and the head jumps one grid step,
//          overshoots and settles.
//   space  one hit leaves a ring at the centre; every repeat springs a little further out.
//   keep   the last minute runs along a strip. a clip of it is lifted and dragged into the
//          host, and springs back. it can be dragged by hand.

(() => {
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const INK = '#ededed', DIM = '#979797', LINE = '#2c2c2c', RED = '#cf3a2e';

  // a damped spring: x is pulled toward target. k stiffness, c damping, m mass.
  class Spring {
    constructor(x, k = 170, c = 22, m = 1) { Object.assign(this, { x, v: 0, target: x, k, c, m }); }
    step(dt) {
      // a few small steps per frame keep stiff springs stable
      const n = Math.ceil(dt / 0.004), h = dt / n;
      for (let i = 0; i < n; i++) {
        const a = (-this.k * (this.x - this.target) - this.c * this.v) / this.m;
        this.v += a * h;
        this.x += this.v * h;
      }
      return this.x;
    }
    get still() { return Math.abs(this.x - this.target) < 1e-3 && Math.abs(this.v) < 1e-3; }
    snap(x) { this.x = this.target = x; this.v = 0; }
  }

  // ------------------------------------------------------------ the motions

  function fit(canvas) {
    const ratio = Math.min(window.devicePixelRatio || 1, 1.5);
    const w = canvas.clientWidth, h = canvas.clientHeight;
    if (canvas.width !== Math.round(w * ratio)) { canvas.width = Math.round(w * ratio); canvas.height = Math.round(h * ratio); }
    const g = canvas.getContext('2d');
    g.setTransform(ratio, 0, 0, ratio, 0, 0);
    return { g, w, h };
  }

  // itch: the tape, its grid, one read head, the fly that moves it
  function itchMotion() {
    const STEPS = 8;
    const head = new Spring(3, 320, 13);     // light damping: it overshoots and rings a little
    let wait = 1.2, flash = 0, trail = [];
    return (canvas, dt, t) => {
      const { g, w, h } = fit(canvas);
      wait -= dt;
      if (wait <= 0) {
        // the fly fires: one or two grid steps, back or forth, never off the tape
        let to = head.target + (Math.random() < 0.5 ? -1 : 1) * (Math.random() < 0.7 ? 1 : 2);
        if (to < 1 || to > STEPS - 1) to = head.target - (to - head.target);
        trail.push({ at: head.target, age: 0 });
        head.target = to;
        flash = 1;
        wait = 1.3 + Math.random() * 1.4;
      }
      head.step(dt);
      flash = Math.max(0, flash - dt * 1.8);
      trail = trail.filter((p) => (p.age += dt) < 1.4);

      const left = w * 0.06, right = w * 0.94, y = h * 0.62;
      const at = (s) => left + ((right - left) * s) / STEPS;
      g.clearRect(0, 0, w, h);
      // the tape and its grid
      g.strokeStyle = LINE; g.lineWidth = 2;
      g.beginPath(); g.moveTo(left, y); g.lineTo(right, y); g.stroke();
      for (let s = 0; s <= STEPS; s++) {
        g.fillStyle = DIM; g.globalAlpha = 0.6;
        g.fillRect(at(s) - 0.5, y - (s % 4 ? 6 : 12), 1, s % 4 ? 12 : 24);
      }
      // where the head was
      for (const p of trail) {
        g.globalAlpha = 0.35 * (1 - p.age / 1.4);
        g.fillStyle = INK; g.fillRect(at(p.at) - 1, y - h * 0.3, 2, h * 0.3);
      }
      // the head
      const x = at(head.x);
      g.globalAlpha = 1;
      g.fillStyle = INK; g.fillRect(x - 1, y - h * 0.34, 2, h * 0.34 + 14);
      g.beginPath(); g.arc(x, y, 7, 0, Math.PI * 2); g.fill();
      // the fly: a small brain that lights red when it fires, with a nerve to the head
      const bx = w * 0.5, by = h * 0.16;
      if (flash > 0) {
        g.strokeStyle = RED; g.globalAlpha = flash; g.lineWidth = 1.5;
        g.beginPath(); g.moveTo(bx, by + 8); g.quadraticCurveTo(bx, y - h * 0.2, x, y - h * 0.34); g.stroke();
      }
      g.globalAlpha = 0.7; g.fillStyle = DIM; g.font = '11px "Fragment Mono", monospace'; g.textAlign = 'left';
      g.fillText('the fly', bx + 34, by + 4);
      g.fillText('tape, on the grid of your host', left, y + 34);
      g.globalAlpha = 1;
      for (const side of [-1, 1]) {
        g.beginPath();
        g.ellipse(bx + side * 13, by, 14, 10, 0, 0, Math.PI * 2);
        g.fillStyle = flash > 0 ? `rgba(207, 58, 46, ${0.35 + flash * 0.65})` : '#1c1c1c';
        g.fill();
        g.strokeStyle = flash > 0 ? RED : '#3a3a3a'; g.lineWidth = 1; g.stroke();
      }
    };
  }

  // space: rings from the centre, each repeat a step further out, wider than tall (the side)
  function spaceMotion() {
    let rings = [], wait = 0.2;
    return (canvas, dt, t) => {
      const { g, w, h } = fit(canvas);
      wait -= dt;
      if (wait <= 0) {
        // one hit and its repeats: each generation lands a dotted eighth later, further out
        for (let n = 0; n < 6; n++) rings.push({ n, due: n * 0.36, r: new Spring(n ? 0.15 + (n - 1) * 0.16 : 0, 120, 11), age: 0, landed: false });
        wait = 3.2;
      }
      g.clearRect(0, 0, w, h);
      const cx = w / 2, cy = h / 2, unit = Math.min(w * 0.46, h * 0.9);
      g.fillStyle = INK; g.globalAlpha = 1;
      g.beginPath(); g.arc(cx, cy, 3, 0, Math.PI * 2); g.fill();
      for (const ring of rings) {
        ring.age += dt;
        if (ring.age < ring.due) continue;
        if (!ring.landed) { ring.landed = true; ring.r.target = 0.15 + ring.n * 0.16; }
        const r = ring.r.step(dt) * unit;
        const life = (ring.age - ring.due) / 2.8;
        g.globalAlpha = Math.max(0, (1 - life) * 0.85 ** ring.n);
        g.strokeStyle = ring.n ? INK : '#ffffff';
        g.lineWidth = ring.n ? 1.4 : 2.2;
        g.beginPath(); g.ellipse(cx, cy, Math.max(1, r), Math.max(1, r * (1 - ring.n * 0.11)), 0, 0, Math.PI * 2); g.stroke();
      }
      rings = rings.filter((ring) => ring.age - ring.due < 2.8);
      g.globalAlpha = 0.7; g.fillStyle = DIM; g.font = '11px "Fragment Mono", monospace'; g.textAlign = 'center';
      g.fillText('side', 30, cy + 4); g.fillText('side', w - 30, cy + 4);
      g.fillText('mid', cx, 18);
      g.globalAlpha = 1;
    };
  }

  // keep: a strip of the last minute, a clip lifted out of it into the host
  function keepMotion(canvas) {
    const bars = Array.from({ length: 120 }, (_, i) => 0.25 + 0.75 * Math.abs(Math.sin(i * 0.9) * Math.sin(i * 0.23 + 1)) ** 0.7);
    const px = new Spring(0, 160, 20), py = new Spring(0, 160, 20), lift = new Spring(0, 260, 18);
    let phase = 'rest', clock = 1.2, held = false, scroll = 0, dropped = 0;
    let geometry = null;

    const toLocal = (e) => { const b = canvas.getBoundingClientRect(); return { x: e.clientX - b.left, y: e.clientY - b.top }; };
    canvas.addEventListener('pointerdown', (e) => {
      if (!geometry) return;
      const p = toLocal(e), c = geometry.clip;
      if (p.x < c.x + px.x - 10 || p.x > c.x + px.x + c.w + 10 || p.y < c.y + py.x - 20 || p.y > c.y + py.x + c.h + 20) return;
      e.preventDefault(); e.stopPropagation();
      held = { dx: p.x - px.x, dy: p.y - py.x };
      canvas.setPointerCapture(e.pointerId);
      lift.target = 1; phase = 'held';
    });
    canvas.addEventListener('pointermove', (e) => {
      if (!held) return;
      const p = toLocal(e);
      px.target = p.x - held.dx; py.target = p.y - held.dy;
    });
    const release = () => {
      if (!held) return;
      held = false;
      const c = geometry.clip, host = geometry.host;
      const inHost = c.y + py.x + c.h / 2 > host.y - 10;
      if (inHost) { py.target = host.y + 8 - c.y; dropped = 1; phase = 'dropped'; clock = 1.4; }
      else { px.target = 0; py.target = 0; lift.target = 0; phase = 'rest'; clock = 2.5; }
    };
    canvas.addEventListener('pointerup', release);
    canvas.addEventListener('pointercancel', release);

    return (canvas, dt) => {
      const { g, w, h } = fit(canvas);
      const sx = w * 0.06, sw = w * 0.88, sy = h * 0.14, sh = h * 0.3;
      const clip = { x: sx + sw * 0.7, y: sy, w: sw * 0.26, h: sh };
      const host = { x: sx, y: h * 0.66, w: sw, h: h * 0.24 };
      geometry = { clip, host };
      if (!held) {
        clock -= dt;
        if (clock <= 0) {
          if (phase === 'rest') { lift.target = 1; phase = 'lifted'; clock = 0.45; }
          else if (phase === 'lifted') { px.target = host.x + host.w * 0.36 - clip.x; py.target = host.y + 8 - clip.y; phase = 'moving'; clock = 0.9; }
          else if (phase === 'moving') { dropped = 1; phase = 'dropped'; clock = 1.4; }
          else if (phase === 'dropped') { px.target = 0; py.target = 0; lift.target = 0; phase = 'rest'; clock = 2.2; }
        }
      }
      px.step(dt); py.step(dt); lift.step(dt);
      dropped = Math.max(0, dropped - dt * 0.8);
      scroll = (scroll + dt * 6) % bars.length;

      g.clearRect(0, 0, w, h);
      // the strip: the last minute, scrolling
      g.strokeStyle = LINE; g.lineWidth = 1;
      g.beginPath(); g.roundRect(sx, sy, sw, sh, 10); g.stroke();
      const n = 72, bw = sw / n;
      for (let i = 0; i < n; i++) {
        const v = bars[Math.floor(i + scroll) % bars.length];
        const x = sx + i * bw;
        const inClip = x >= clip.x && x < clip.x + clip.w;
        g.fillStyle = inClip ? '#5a5a5a' : '#3d3d3d';
        g.fillRect(x + bw * 0.25, sy + sh / 2 - (v * sh * 0.38), bw * 0.5, v * sh * 0.76);
      }
      g.fillStyle = DIM; g.font = '11px "Fragment Mono", monospace'; g.textAlign = 'left';
      g.fillText('keep: the last minute', sx, sy - 8);
      // the host
      g.strokeStyle = dropped > 0 ? `rgba(237, 237, 237, ${0.25 + dropped * 0.5})` : LINE;
      g.setLineDash([4, 5]);
      g.beginPath(); g.roundRect(host.x, host.y, host.w, host.h, 10); g.stroke();
      g.setLineDash([]);
      g.fillText('your host', host.x, host.y + host.h + 16);
      // the clip, lifted on a spring
      const cx = clip.x + px.x, cy = clip.y + py.x - lift.x * 8;
      g.save();
      g.shadowColor = 'rgba(255, 255, 255, 0.25)'; g.shadowBlur = 24 * lift.x;
      g.fillStyle = `rgba(237, 237, 237, ${0.08 + lift.x * 0.1})`;
      g.strokeStyle = INK; g.lineWidth = 1.5;
      g.beginPath(); g.roundRect(cx, cy, clip.w, clip.h, 8); g.fill(); g.stroke();
      g.restore();
      const cn = Math.round(clip.w / bw);
      for (let i = 0; i < cn; i++) {
        const v = bars[(Math.floor((clip.x - sx) / bw) + i + 7) % bars.length];
        g.fillStyle = INK;
        g.fillRect(cx + i * bw + bw * 0.25, cy + clip.h / 2 - v * clip.h * 0.34, bw * 0.5, v * clip.h * 0.68);
      }
      g.fillStyle = INK; g.fillText('.wav', cx + 6, cy + clip.h + 14 + lift.x * 0);
    };
  }

  // ------------------------------------------------------------ the deck

  let deck = null;

  function teardown() { if (deck) { cancelAnimationFrame(deck.frame); clearInterval(deck.auto); deck = null; } }

  function initDeck() {
    teardown();
    const root = document.querySelector('.deck');
    if (!root) return;
    const slides = [...root.querySelectorAll('.slide')];
    const tabs = [...root.querySelectorAll('[role="tab"]')];
    const track = root.querySelector('.slides');
    const pos = new Spring(0, 140, 21);          // the slide position, 0 .. 2, continuous
    const motions = slides.map((slide) => {
      const canvas = slide.querySelector('canvas[data-motion]');
      const kind = canvas.dataset.motion;
      return { canvas, draw: kind === 'itch' ? itchMotion() : kind === 'space' ? spaceMotion() : keepMotion(canvas) };
    });
    // the layers of a slide move at different rates, so they arrive one after another
    const layers = slides.map((slide) => [...slide.querySelectorAll('[data-depth]')].map((el) => ({ el, depth: Number(el.dataset.depth) })));
    let current = 0, autoplay = !reducedMotion, last = performance.now(), visible = true, progress = 0;
    const DWELL = 7;   // seconds on a slide while it plays by itself

    function select(index, { user = false } = {}) {
      current = (index + slides.length) % slides.length;
      pos.target = current;
      progress = 0;
      if (user) autoplay = false;
      tabs.forEach((tab, i) => {
        tab.setAttribute('aria-selected', String(i === current));
        tab.tabIndex = i === current ? 0 : -1;
      });
      slides.forEach((slide, i) => { slide.setAttribute('aria-hidden', String(i !== current)); slide.inert = i !== current; });
      root.classList.toggle('stopped', !autoplay);
      if (reducedMotion) pos.snap(current);
    }

    tabs.forEach((tab, i) => {
      tab.addEventListener('click', () => select(i, { user: true }));
      tab.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
          e.preventDefault();
          select(current + (e.key === 'ArrowRight' ? 1 : -1), { user: true });
          tabs[current].focus();
        }
      });
    });

    // swipe or drag the slides: the position follows the hand, and a fling carries on
    let drag = null;
    track.addEventListener('pointerdown', (e) => {
      if (e.button !== 0 || e.target.closest('a, button, canvas')) return;
      drag = { x: e.clientX, y: e.clientY, from: pos.x, moved: false, t: performance.now(), lastX: e.clientX, v: 0 };
    });
    window.addEventListener('pointermove', (e) => {
      if (!drag) return;
      const dx = e.clientX - drag.x;
      if (!drag.moved && Math.abs(dx) < 8) return;
      if (!drag.moved && Math.abs(e.clientY - drag.y) > Math.abs(dx)) { drag = null; return; }   // a scroll
      drag.moved = true;
      const width = track.clientWidth;
      let p = drag.from - dx / width;
      if (p < 0) p *= 0.35; if (p > slides.length - 1) p = slides.length - 1 + (p - slides.length + 1) * 0.35;   // rubber band
      const now = performance.now();
      drag.v = (-(e.clientX - drag.lastX) / width) / Math.max(0.001, (now - drag.t) / 1000);
      drag.lastX = e.clientX; drag.t = now;
      pos.snap(p);
    });
    const endDrag = () => {
      if (!drag) return;
      if (drag.moved) {
        pos.v = drag.v;
        const aim = Math.max(current - 1, Math.min(current + 1, Math.round(pos.x + drag.v * 0.18)));
        select(Math.max(0, Math.min(slides.length - 1, aim)), { user: true });
        pos.v = drag.v;
      }
      drag = null;
    };
    window.addEventListener('pointerup', endDrag);
    window.addEventListener('pointercancel', endDrag);

    root.addEventListener('focusin', () => { autoplay = false; root.classList.add('stopped'); });
    new IntersectionObserver(([entry]) => { visible = entry.isIntersecting; }).observe(root);

    function frame(now) {
      const state = deck;
      if (!state) return;
      state.frame = requestAnimationFrame(frame);
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      if (!visible || document.hidden) return;

      if (autoplay) {
        progress += dt / DWELL;
        if (progress >= 1) select(current + 1);
      }
      root.style.setProperty('--progress', autoplay ? progress.toFixed(3) : 1);

      const p = pos.step(dt);
      const width = track.clientWidth;
      slides.forEach((slide, i) => {
        const off = i - p;                       // 0 when this slide is in place
        const away = Math.min(1, Math.abs(off));
        slide.style.opacity = String(Math.max(0, 1 - away * 1.6));
        slide.style.visibility = away > 0.98 ? 'hidden' : 'visible';
        for (const { el, depth } of layers[i]) {
          el.style.transform = `translate3d(${(off * width * depth).toFixed(1)}px, 0, 0)`;
        }
        if (away < 0.98) motions[i].draw(motions[i].canvas, reducedMotion ? 0 : dt, now / 1000);
      });
    }
    deck = { frame: 0 };
    select(0);
    deck.frame = requestAnimationFrame(frame);
  }

  window.AFFERENT_DECK = { init: initDeck };
})();
