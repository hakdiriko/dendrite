// afferent.page: one gesture, one screen.
// on the slide pages the page does not scroll. the finger (or the wheel, or a key) moves the
// stack of screens, and letting go springs it straight to the next or the previous one:
// no coasting, no settling back. the spring takes the speed the finger had, so a quick flick
// arrives quickly. the text pages (legal, specification) keep ordinary scrolling.
(() => {
  const main = document.getElementById('content');
  if (!main) return;
  const root = document.documentElement;
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');

  let active = false;
  let index = 0;
  let y = 0;            // where the stack is drawn, in px (0 or negative)
  let velocity = 0;     // px per second, for the spring
  let target = 0;
  let frame = 0;
  let last = 0;

  const slides = () => [...main.querySelectorAll(':scope > .slide')];
  const height = () => main.clientHeight || window.innerHeight;
  const draw = () => main.style.setProperty('--y', `${y.toFixed(2)}px`);

  function mark() {
    slides().forEach((s, i) => {
      s.classList.toggle('is-active', i === index);
    });
  }

  // a slightly under-damped spring: fast out, settles in about a third of a second
  function tick(now) {
    const dt = Math.min(0.032, (now - last) / 1000 || 0.016);
    last = now;
    if (reduced.matches) {
      y += (target - y) * Math.min(1, dt * 18);
      if (Math.abs(target - y) < 0.5) y = target;
    } else {
      const stiffness = 320;
      const damping = 2 * Math.sqrt(stiffness) * 0.88;
      velocity += (stiffness * (target - y) - damping * velocity) * dt;
      y += velocity * dt;
      if (Math.abs(target - y) < 0.4 && Math.abs(velocity) < 8) { y = target; velocity = 0; }
    }
    draw();
    if (y !== target) frame = requestAnimationFrame(tick);
    else frame = 0;
  }
  const moving = () => frame !== 0;

  function to(i, { instant = false, speed = 0 } = {}) {
    const count = slides().length;
    if (!count) return;
    index = Math.max(0, Math.min(count - 1, i));
    target = -index * height();
    mark();
    cancelAnimationFrame(frame);
    frame = 0;
    if (instant) { y = target; velocity = 0; draw(); return; }
    velocity = speed;
    last = performance.now();
    frame = requestAnimationFrame(tick);
  }
  const step = (direction, speed) => to(index + direction, { speed });

  function setActive() {
    const on = main.dataset.page === 'slides' && slides().length > 1;
    if (on === active) { if (on) to(Math.min(index, slides().length - 1), { instant: true }); return; }
    active = on;
    root.classList.toggle('paged', on);
    if (on) to(0, { instant: true });
    else { main.style.removeProperty('--y'); for (const s of slides()) s.classList.remove('is-active'); }
  }

  // the rest of the site still asks to scroll to a section or to the top: answer with the pager
  const scrollIntoView = Element.prototype.scrollIntoView;
  Element.prototype.scrollIntoView = function (options) {
    const slide = active && this.closest && this.closest('#content > .slide');
    if (!slide) return scrollIntoView.call(this, options);
    to(slides().indexOf(slide), { instant: options && options.behavior === 'instant' });
  };
  const scrollTo = window.scrollTo.bind(window);
  window.scrollTo = (a, b) => {
    const top = typeof a === 'object' ? a.top : b;
    if (!active) return scrollTo(a, b);
    if (top === 0) to(0, { instant: typeof a === 'object' && a.behavior === 'instant' });
  };

  // ---------------------------------------------------------------- touch
  let touch = null;
  document.addEventListener('touchstart', (e) => {
    if (!active || e.touches.length !== 1) { touch = null; return; }
    const t = e.touches[0];
    cancelAnimationFrame(frame); frame = 0;          // catch it mid-flight
    touch = { x: t.clientX, y: t.clientY, base: y, lastY: t.clientY, lastT: e.timeStamp, v: 0, drag: false };
  }, { passive: true });

  document.addEventListener('touchmove', (e) => {
    if (!active) return;
    if (e.touches.length !== 1 || !touch) return;   // two fingers: let the reader zoom
    e.preventDefault();                               // the page itself never scrolls or bounces
    const t = e.touches[0];
    const dy = t.clientY - touch.y;
    if (!touch.drag) {
      if (Math.abs(dy) < 6 || Math.abs(dy) < Math.abs(t.clientX - touch.x)) return;
      touch.drag = true;
    }
    const dt = Math.max(1, e.timeStamp - touch.lastT);
    touch.v = 0.75 * ((t.clientY - touch.lastY) / dt) + 0.25 * touch.v;   // px per ms, smoothed
    touch.lastY = t.clientY; touch.lastT = e.timeStamp;
    let next = touch.base + dy;
    const min = -(slides().length - 1) * height();
    if (next > 0) next *= 0.3;                        // a little give past the first and last screen
    if (next < min) next = min + (next - min) * 0.3;
    y = next; draw();
  }, { passive: false });

  const release = (e) => {
    if (!active || !touch) return;
    const t = touch; touch = null;
    if (!t.drag) { if (y !== target) to(index); return; }
    const dy = t.lastY - t.y;
    const flick = e.timeStamp - t.lastT < 80 ? t.v : 0;   // a finger that stopped before lifting has no speed
    let direction = 0;
    if (dy < -36 || flick < -0.3) direction = 1;
    else if (dy > 36 || flick > 0.3) direction = -1;
    to(index + direction, { speed: flick * 1000 });
  };
  document.addEventListener('touchend', release, { passive: true });
  document.addEventListener('touchcancel', release, { passive: true });

  // ---------------------------------------------------------------- wheel and trackpad
  // a trackpad keeps sending a fading stream after the fingers lift. one stream is one screen:
  // the next screen needs a pause or a fresh push that is clearly stronger than the fading tail.
  let wheel = { at: 0, size: 0, sum: 0, locked: false };
  window.addEventListener('wheel', (e) => {
    if (!active || e.ctrlKey) return;                 // ctrl + wheel is zoom
    e.preventDefault();
    const delta = e.deltaY * (e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? height() : 1);
    const size = Math.abs(delta);
    const gap = e.timeStamp - wheel.at;
    wheel.at = e.timeStamp;
    if (wheel.locked) {
      const fresh = gap > 220 || (!moving() && size > 24 && size > wheel.size * 1.8);
      wheel.size = size;
      if (!fresh) return;
      wheel.locked = false;
      wheel.sum = 0;
    }
    if (gap > 220) wheel.sum = 0;
    wheel.size = size;
    wheel.sum += delta;
    if (Math.abs(wheel.sum) < 24) return;
    const direction = Math.sign(wheel.sum);
    wheel.sum = 0;
    wheel.locked = true;
    if (index + direction < 0 || index + direction >= slides().length) return;
    step(direction, 0);
  }, { passive: false });

  // ---------------------------------------------------------------- keys and focus
  document.addEventListener('keydown', (e) => {
    if (!active || e.altKey || e.ctrlKey || e.metaKey) return;
    const typing = e.target.closest && e.target.closest('input, textarea, select, [contenteditable]');
    if (typing) return;
    const onControl = e.target.closest && e.target.closest('a, button');
    let direction = 0;
    if (e.key === 'ArrowDown' || e.key === 'PageDown' || (e.key === ' ' && !onControl && !e.shiftKey)) direction = 1;
    else if (e.key === 'ArrowUp' || e.key === 'PageUp' || (e.key === ' ' && !onControl && e.shiftKey)) direction = -1;
    else if (e.key === 'Home') { e.preventDefault(); return to(0); }
    else if (e.key === 'End') { e.preventDefault(); return to(slides().length - 1); }
    if (!direction) return;
    e.preventDefault();
    if (e.repeat && moving()) return;
    step(direction, 0);
  });

  // tabbing to a link on another screen brings that screen in
  document.addEventListener('focusin', (e) => {
    if (!active) return;
    const slide = e.target.closest && e.target.closest('#content > .slide');
    if (!slide) return;
    const i = slides().indexOf(slide);
    if (i !== index) to(i);
  });

  window.addEventListener('resize', () => { if (active) to(index, { instant: true }); });

  // the site swaps <main> when moving between pages without reloading
  new MutationObserver(setActive).observe(main, { childList: true, attributes: true, attributeFilter: ['data-page'] });
  setActive();
  const start = location.hash && document.getElementById(location.hash.slice(1));
  if (active && start) start.scrollIntoView({ behavior: 'instant' });

  window.AFFERENT_PAGER = { to, get index() { return index; }, get count() { return slides().length; } };
})();
